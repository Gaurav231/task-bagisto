<?php return array (
  'app' => 
  array (
    'name' => 'Bagisto',
    'env' => 'local',
    'debug' => true,
    'url' => 'http://localhost',
    'admin_url' => 'admin',
    'timezone' => 'Asia/Kolkata',
    'locale' => 'en',
    'fallback_locale' => 'en',
    'default_country' => NULL,
    'currency' => 'USD',
    'channel' => 'default',
    'key' => 'base64:sePYEZH89G+PZXmgmnOPI9viRyVPWYDZAcccGm9n4tg=',
    'cipher' => 'AES-256-CBC',
    'providers' => 
    array (
      0 => 'Illuminate\\Auth\\AuthServiceProvider',
      1 => 'Illuminate\\Broadcasting\\BroadcastServiceProvider',
      2 => 'Illuminate\\Bus\\BusServiceProvider',
      3 => 'Illuminate\\Cache\\CacheServiceProvider',
      4 => 'Illuminate\\Foundation\\Providers\\ConsoleSupportServiceProvider',
      5 => 'Illuminate\\Cookie\\CookieServiceProvider',
      6 => 'Illuminate\\Database\\DatabaseServiceProvider',
      7 => 'Illuminate\\Encryption\\EncryptionServiceProvider',
      8 => 'Illuminate\\Filesystem\\FilesystemServiceProvider',
      9 => 'Illuminate\\Foundation\\Providers\\FoundationServiceProvider',
      10 => 'Illuminate\\Hashing\\HashServiceProvider',
      11 => 'Illuminate\\Mail\\MailServiceProvider',
      12 => 'Illuminate\\Notifications\\NotificationServiceProvider',
      13 => 'Illuminate\\Pagination\\PaginationServiceProvider',
      14 => 'Illuminate\\Pipeline\\PipelineServiceProvider',
      15 => 'Illuminate\\Queue\\QueueServiceProvider',
      16 => 'Illuminate\\Redis\\RedisServiceProvider',
      17 => 'Illuminate\\Auth\\Passwords\\PasswordResetServiceProvider',
      18 => 'Illuminate\\Session\\SessionServiceProvider',
      19 => 'Illuminate\\Translation\\TranslationServiceProvider',
      20 => 'Illuminate\\Validation\\ValidationServiceProvider',
      21 => 'Illuminate\\View\\ViewServiceProvider',
      22 => 'Astrotomic\\Translatable\\TranslatableServiceProvider',
      23 => 'Barryvdh\\DomPDF\\ServiceProvider',
      24 => 'Intervention\\Image\\ImageServiceProvider',
      25 => 'Konekt\\Concord\\ConcordServiceProvider',
      26 => 'Maatwebsite\\Excel\\ExcelServiceProvider',
      27 => 'Prettus\\Repository\\Providers\\RepositoryServiceProvider',
      28 => 'App\\Providers\\AppServiceProvider',
      29 => 'App\\Providers\\AuthServiceProvider',
      30 => 'App\\Providers\\EventServiceProvider',
      31 => 'App\\Providers\\RouteServiceProvider',
      32 => 'Webkul\\Admin\\Providers\\AdminServiceProvider',
      33 => 'Webkul\\Attribute\\Providers\\AttributeServiceProvider',
      34 => 'Webkul\\CartRule\\Providers\\CartRuleServiceProvider',
      35 => 'Webkul\\CatalogRule\\Providers\\CatalogRuleServiceProvider',
      36 => 'Webkul\\Category\\Providers\\CategoryServiceProvider',
      37 => 'Webkul\\Checkout\\Providers\\CheckoutServiceProvider',
      38 => 'Webkul\\CMS\\Providers\\CMSServiceProvider',
      39 => 'Webkul\\Core\\Providers\\CoreServiceProvider',
      40 => 'Webkul\\Core\\Providers\\EnvValidatorServiceProvider',
      41 => 'Webkul\\Customer\\Providers\\CustomerServiceProvider',
      42 => 'Webkul\\DataGrid\\Providers\\DataGridServiceProvider',
      43 => 'Webkul\\DebugBar\\Providers\\DebugBarServiceProvider',
      44 => 'Webkul\\FPC\\Providers\\FPCServiceProvider',
      45 => 'Webkul\\Installer\\Providers\\InstallerServiceProvider',
      46 => 'Webkul\\Inventory\\Providers\\InventoryServiceProvider',
      47 => 'Webkul\\Marketing\\Providers\\MarketingServiceProvider',
      48 => 'Webkul\\Notification\\Providers\\NotificationServiceProvider',
      49 => 'Webkul\\Payment\\Providers\\PaymentServiceProvider',
      50 => 'Webkul\\Paypal\\Providers\\PaypalServiceProvider',
      51 => 'Webkul\\Product\\Providers\\ProductServiceProvider',
      52 => 'Webkul\\Rule\\Providers\\RuleServiceProvider',
      53 => 'Webkul\\Sales\\Providers\\SalesServiceProvider',
      54 => 'Webkul\\Shipping\\Providers\\ShippingServiceProvider',
      55 => 'Webkul\\Shop\\Providers\\ShopServiceProvider',
      56 => 'Webkul\\Sitemap\\Providers\\SitemapServiceProvider',
      57 => 'Webkul\\SocialLogin\\Providers\\SocialLoginServiceProvider',
      58 => 'Webkul\\SocialShare\\Providers\\SocialShareServiceProvider',
      59 => 'Webkul\\Tax\\Providers\\TaxServiceProvider',
      60 => 'Webkul\\Theme\\Providers\\ThemeServiceProvider',
      61 => 'Webkul\\User\\Providers\\UserServiceProvider',
    ),
    'aliases' => 
    array (
      'App' => 'Illuminate\\Support\\Facades\\App',
      'Arr' => 'Illuminate\\Support\\Arr',
      'Artisan' => 'Illuminate\\Support\\Facades\\Artisan',
      'Auth' => 'Illuminate\\Support\\Facades\\Auth',
      'Blade' => 'Illuminate\\Support\\Facades\\Blade',
      'Broadcast' => 'Illuminate\\Support\\Facades\\Broadcast',
      'Bus' => 'Illuminate\\Support\\Facades\\Bus',
      'Cache' => 'Illuminate\\Support\\Facades\\Cache',
      'Config' => 'Illuminate\\Support\\Facades\\Config',
      'Cookie' => 'Illuminate\\Support\\Facades\\Cookie',
      'Crypt' => 'Illuminate\\Support\\Facades\\Crypt',
      'Date' => 'Illuminate\\Support\\Facades\\Date',
      'DB' => 'Illuminate\\Support\\Facades\\DB',
      'Eloquent' => 'Illuminate\\Database\\Eloquent\\Model',
      'Event' => 'Illuminate\\Support\\Facades\\Event',
      'File' => 'Illuminate\\Support\\Facades\\File',
      'Gate' => 'Illuminate\\Support\\Facades\\Gate',
      'Hash' => 'Illuminate\\Support\\Facades\\Hash',
      'Http' => 'Illuminate\\Support\\Facades\\Http',
      'Js' => 'Illuminate\\Support\\Js',
      'Lang' => 'Illuminate\\Support\\Facades\\Lang',
      'Log' => 'Illuminate\\Support\\Facades\\Log',
      'Mail' => 'Illuminate\\Support\\Facades\\Mail',
      'Notification' => 'Illuminate\\Support\\Facades\\Notification',
      'Password' => 'Illuminate\\Support\\Facades\\Password',
      'Process' => 'Illuminate\\Support\\Facades\\Process',
      'Queue' => 'Illuminate\\Support\\Facades\\Queue',
      'RateLimiter' => 'Illuminate\\Support\\Facades\\RateLimiter',
      'Redirect' => 'Illuminate\\Support\\Facades\\Redirect',
      'Request' => 'Illuminate\\Support\\Facades\\Request',
      'Response' => 'Illuminate\\Support\\Facades\\Response',
      'Route' => 'Illuminate\\Support\\Facades\\Route',
      'Schema' => 'Illuminate\\Support\\Facades\\Schema',
      'Session' => 'Illuminate\\Support\\Facades\\Session',
      'Storage' => 'Illuminate\\Support\\Facades\\Storage',
      'Str' => 'Illuminate\\Support\\Str',
      'URL' => 'Illuminate\\Support\\Facades\\URL',
      'Validator' => 'Illuminate\\Support\\Facades\\Validator',
      'View' => 'Illuminate\\Support\\Facades\\View',
      'Vite' => 'Illuminate\\Support\\Facades\\Vite',
      'Captcha' => 'Webkul\\Customer\\Facades\\Captcha',
      'Cart' => 'Webkul\\Checkout\\Facades\\Cart',
      'Concord' => 'Konekt\\Concord\\Facades\\Concord',
      'Core' => 'Webkul\\Core\\Facades\\Core',
      'Datagrid' => 'Webkul\\Ui\\DataGrid\\Facades\\DataGrid',
      'Excel' => 'Maatwebsite\\Excel\\Facades\\Excel',
      'Helper' => 'Konekt\\Concord\\Facades\\Helper',
      'Image' => 'Intervention\\Image\\Facades\\Image',
      'PDF' => 'Barryvdh\\DomPDF\\Facade\\Pdf',
      'ProductImage' => 'Webkul\\Product\\Facades\\ProductImage',
      'ProductVideo' => 'Webkul\\Product\\Facades\\ProductVideo',
      'Redis' => 'Illuminate\\Support\\Facades\\Redis',
    ),
  ),
  'auth' => 
  array (
    'defaults' => 
    array (
      'guard' => 'customer',
      'passwords' => 'customers',
    ),
    'guards' => 
    array (
      'customer' => 
      array (
        'driver' => 'session',
        'provider' => 'customers',
      ),
      'admin' => 
      array (
        'driver' => 'session',
        'provider' => 'admins',
      ),
      'sanctum' => 
      array (
        'driver' => 'sanctum',
        'provider' => NULL,
      ),
    ),
    'providers' => 
    array (
      'customers' => 
      array (
        'driver' => 'eloquent',
        'model' => 'Webkul\\Customer\\Models\\Customer',
      ),
      'admins' => 
      array (
        'driver' => 'eloquent',
        'model' => 'Webkul\\User\\Models\\Admin',
      ),
    ),
    'passwords' => 
    array (
      'customers' => 
      array (
        'provider' => 'customers',
        'table' => 'customer_password_resets',
        'expire' => 60,
        'throttle' => 60,
      ),
      'admins' => 
      array (
        'provider' => 'admins',
        'table' => 'admin_password_resets',
        'expire' => 60,
        'throttle' => 60,
      ),
    ),
  ),
  'bagisto-vite' => 
  array (
    'viters' => 
    array (
      'admin' => 
      array (
        'hot_file' => 'admin-default-vite.hot',
        'build_directory' => 'themes/admin/default/build',
        'package_assets_directory' => 'src/Resources/assets',
      ),
      'shop' => 
      array (
        'hot_file' => 'shop-default-vite.hot',
        'build_directory' => 'themes/shop/default/build',
        'package_assets_directory' => 'src/Resources/assets',
      ),
      'installer' => 
      array (
        'hot_file' => 'installer-default-vite.hot',
        'build_directory' => 'themes/installer/default/build',
        'package_assets_directory' => 'src/Resources/assets',
      ),
    ),
  ),
  'breadcrumbs' => 
  array (
    'view' => 'breadcrumbs::bootstrap5',
    'files' => 'C:\\xampp\\htdocs\\bagisto\\routes/breadcrumbs.php',
    'unnamed-route-exception' => true,
    'missing-route-bound-breadcrumb-exception' => true,
    'invalid-named-breadcrumb-exception' => true,
    'manager-class' => 'Diglactic\\Breadcrumbs\\Manager',
    'generator-class' => 'Diglactic\\Breadcrumbs\\Generator',
  ),
  'broadcasting' => 
  array (
    'default' => 'log',
    'connections' => 
    array (
      'pusher' => 
      array (
        'driver' => 'pusher',
        'key' => '',
        'secret' => '',
        'app_id' => '',
        'options' => 
        array (
          'cluster' => 'mt1',
          'encrypted' => true,
        ),
      ),
      'redis' => 
      array (
        'driver' => 'redis',
        'connection' => 'default',
      ),
      'log' => 
      array (
        'driver' => 'log',
      ),
      'null' => 
      array (
        'driver' => 'null',
      ),
    ),
  ),
  'cache' => 
  array (
    'default' => 'file',
    'stores' => 
    array (
      'apc' => 
      array (
        'driver' => 'apc',
      ),
      'array' => 
      array (
        'driver' => 'array',
      ),
      'database' => 
      array (
        'driver' => 'database',
        'table' => 'cache',
        'connection' => NULL,
      ),
      'file' => 
      array (
        'driver' => 'file',
        'path' => 'C:\\xampp\\htdocs\\bagisto\\storage\\framework/cache/data',
      ),
      'memcached' => 
      array (
        'driver' => 'memcached',
        'persistent_id' => NULL,
        'sasl' => 
        array (
          0 => NULL,
          1 => NULL,
        ),
        'options' => 
        array (
        ),
        'servers' => 
        array (
          0 => 
          array (
            'host' => '127.0.0.1',
            'port' => 11211,
            'weight' => 100,
          ),
        ),
      ),
      'redis' => 
      array (
        'driver' => 'redis',
        'connection' => 'cache',
      ),
    ),
    'prefix' => 'bagisto_cache',
  ),
  'concord' => 
  array (
    'convention' => 'Webkul\\Core\\CoreConvention',
    'modules' => 
    array (
      0 => 'Webkul\\Admin\\Providers\\ModuleServiceProvider',
      1 => 'Webkul\\Attribute\\Providers\\ModuleServiceProvider',
      2 => 'Webkul\\CartRule\\Providers\\ModuleServiceProvider',
      3 => 'Webkul\\CatalogRule\\Providers\\ModuleServiceProvider',
      4 => 'Webkul\\Category\\Providers\\ModuleServiceProvider',
      5 => 'Webkul\\Checkout\\Providers\\ModuleServiceProvider',
      6 => 'Webkul\\Core\\Providers\\ModuleServiceProvider',
      7 => 'Webkul\\CMS\\Providers\\ModuleServiceProvider',
      8 => 'Webkul\\Customer\\Providers\\ModuleServiceProvider',
      9 => 'Webkul\\Inventory\\Providers\\ModuleServiceProvider',
      10 => 'Webkul\\Marketing\\Providers\\ModuleServiceProvider',
      11 => 'Webkul\\Payment\\Providers\\ModuleServiceProvider',
      12 => 'Webkul\\Paypal\\Providers\\ModuleServiceProvider',
      13 => 'Webkul\\Product\\Providers\\ModuleServiceProvider',
      14 => 'Webkul\\Rule\\Providers\\ModuleServiceProvider',
      15 => 'Webkul\\Sales\\Providers\\ModuleServiceProvider',
      16 => 'Webkul\\Shipping\\Providers\\ModuleServiceProvider',
      17 => 'Webkul\\Shop\\Providers\\ModuleServiceProvider',
      18 => 'Webkul\\SocialLogin\\Providers\\ModuleServiceProvider',
      19 => 'Webkul\\Tax\\Providers\\ModuleServiceProvider',
      20 => 'Webkul\\Theme\\Providers\\ModuleServiceProvider',
      21 => 'Webkul\\User\\Providers\\ModuleServiceProvider',
      22 => 'Webkul\\Sitemap\\Providers\\ModuleServiceProvider',
    ),
  ),
  'cors' => 
  array (
    'paths' => 
    array (
      0 => 'api/*',
      1 => 'sanctum/csrf-cookie',
    ),
    'allowed_methods' => 
    array (
      0 => '*',
    ),
    'allowed_origins' => 
    array (
      0 => '*',
    ),
    'allowed_origins_patterns' => 
    array (
    ),
    'allowed_headers' => 
    array (
      0 => '*',
    ),
    'exposed_headers' => 
    array (
    ),
    'max_age' => 0,
    'supports_credentials' => false,
  ),
  'database' => 
  array (
    'default' => 'mysql',
    'connections' => 
    array (
      'sqlite' => 
      array (
        'driver' => 'sqlite',
        'database' => 'bagisto',
        'prefix' => '',
      ),
      'mysql' => 
      array (
        'driver' => 'mysql',
        'host' => '127.0.0.1',
        'port' => '3306',
        'database' => 'bagisto',
        'username' => 'root',
        'password' => '',
        'unix_socket' => '',
        'charset' => 'utf8mb4',
        'collation' => 'utf8mb4_unicode_ci',
        'prefix' => '',
        'strict' => false,
        'engine' => 'InnoDB ROW_FORMAT=DYNAMIC',
      ),
      'pgsql' => 
      array (
        'driver' => 'pgsql',
        'host' => '127.0.0.1',
        'port' => '3306',
        'database' => 'bagisto',
        'username' => 'root',
        'password' => '',
        'charset' => 'utf8',
        'prefix' => NULL,
        'schema' => 'public',
        'sslmode' => 'prefer',
      ),
      'sqlsrv' => 
      array (
        'driver' => 'sqlsrv',
        'host' => '127.0.0.1',
        'port' => '3306',
        'database' => 'bagisto',
        'username' => 'root',
        'password' => '',
        'charset' => 'utf8',
        'prefix' => '',
      ),
    ),
    'migrations' => 'migrations',
    'redis' => 
    array (
      'client' => 'predis',
      'default' => 
      array (
        'host' => '127.0.0.1',
        'password' => NULL,
        'port' => '6379',
        'database' => '0',
      ),
      'cache' => 
      array (
        'host' => '127.0.0.1',
        'password' => NULL,
        'port' => '6379',
        'database' => '1',
      ),
      'session' => 
      array (
        'host' => '127.0.0.1',
        'password' => NULL,
        'port' => '6379',
        'database' => '2',
      ),
    ),
  ),
  'debugbar' => 
  array (
    'enabled' => NULL,
    'except' => 
    array (
      0 => 'telescope*',
      1 => 'horizon*',
    ),
    'storage' => 
    array (
      'enabled' => true,
      'driver' => 'file',
      'path' => 'C:\\xampp\\htdocs\\bagisto\\storage\\debugbar',
      'connection' => NULL,
      'provider' => '',
      'hostname' => '127.0.0.1',
      'port' => 2304,
    ),
    'editor' => 'phpstorm',
    'remote_sites_path' => '',
    'local_sites_path' => '',
    'include_vendors' => true,
    'capture_ajax' => true,
    'add_ajax_timing' => false,
    'error_handler' => false,
    'clockwork' => false,
    'collectors' => 
    array (
      'phpinfo' => true,
      'messages' => true,
      'time' => true,
      'memory' => true,
      'exceptions' => true,
      'log' => true,
      'db' => true,
      'views' => true,
      'route' => true,
      'auth' => false,
      'gate' => true,
      'session' => true,
      'symfony_request' => true,
      'mail' => true,
      'laravel' => false,
      'events' => false,
      'default_request' => false,
      'logs' => false,
      'files' => false,
      'config' => false,
      'cache' => false,
      'models' => true,
      'livewire' => true,
    ),
    'options' => 
    array (
      'auth' => 
      array (
        'show_name' => true,
      ),
      'db' => 
      array (
        'with_params' => true,
        'backtrace' => true,
        'backtrace_exclude_paths' => 
        array (
        ),
        'timeline' => false,
        'duration_background' => true,
        'explain' => 
        array (
          'enabled' => false,
          'types' => 
          array (
            0 => 'SELECT',
          ),
        ),
        'hints' => false,
        'show_copy' => false,
        'slow_threshold' => false,
      ),
      'mail' => 
      array (
        'full_log' => false,
      ),
      'views' => 
      array (
        'timeline' => false,
        'data' => false,
        'exclude_paths' => 
        array (
        ),
      ),
      'route' => 
      array (
        'label' => true,
      ),
      'logs' => 
      array (
        'file' => NULL,
      ),
      'cache' => 
      array (
        'values' => true,
      ),
    ),
    'inject' => true,
    'route_prefix' => '_debugbar',
    'route_domain' => NULL,
    'theme' => 'auto',
    'debug_backtrace_limit' => 50,
  ),
  'dompdf' => 
  array (
    'show_warnings' => false,
    'public_path' => NULL,
    'convert_entities' => true,
    'options' => 
    array (
      'font_dir' => 'C:\\xampp\\htdocs\\bagisto\\storage\\fonts',
      'font_cache' => 'C:\\xampp\\htdocs\\bagisto\\storage\\fonts',
      'temp_dir' => 'C:\\Users\\GAURAV~1\\AppData\\Local\\Temp',
      'chroot' => 'C:\\xampp\\htdocs\\bagisto',
      'allowed_protocols' => 
      array (
        'file://' => 
        array (
          'rules' => 
          array (
          ),
        ),
        'http://' => 
        array (
          'rules' => 
          array (
          ),
        ),
        'https://' => 
        array (
          'rules' => 
          array (
          ),
        ),
      ),
      'log_output_file' => NULL,
      'enable_font_subsetting' => false,
      'pdf_backend' => 'CPDF',
      'default_media_type' => 'screen',
      'default_paper_size' => 'a4',
      'default_paper_orientation' => 'portrait',
      'default_font' => 'serif',
      'dpi' => 96,
      'enable_php' => false,
      'enable_javascript' => true,
      'enable_remote' => true,
      'font_height_ratio' => 1.1,
      'enable_html5_parser' => true,
    ),
  ),
  'elasticsearch' => 
  array (
    'defaultConnection' => 'default',
    'connections' => 
    array (
      'default' => 
      array (
        'hosts' => 
        array (
          0 => 
          array (
            'host' => 'localhost',
            'port' => 9200,
            'scheme' => NULL,
            'user' => NULL,
            'pass' => NULL,
            'api_id' => NULL,
            'api_key' => NULL,
            'aws' => false,
            'aws_region' => '',
            'aws_key' => '',
            'aws_secret' => '',
            'aws_credentials' => NULL,
            'aws_session_token' => NULL,
          ),
        ),
        'sslVerification' => NULL,
        'logging' => false,
        'logPath' => 'C:\\xampp\\htdocs\\bagisto\\storage\\logs/elasticsearch.log',
        'logLevel' => 200,
        'retries' => NULL,
        'sniffOnStart' => false,
        'httpHandler' => NULL,
        'connectionPool' => NULL,
        'connectionSelector' => NULL,
        'serializer' => NULL,
        'connectionFactory' => NULL,
        'endpoint' => NULL,
        'namespaces' => 
        array (
        ),
        'tracer' => NULL,
      ),
    ),
  ),
  'excel' => 
  array (
    'exports' => 
    array (
      'chunk_size' => 1000,
      'pre_calculate_formulas' => false,
      'strict_null_comparison' => false,
      'csv' => 
      array (
        'delimiter' => ',',
        'enclosure' => '"',
        'line_ending' => '
',
        'use_bom' => false,
        'include_separator_line' => false,
        'excel_compatibility' => false,
        'output_encoding' => '',
        'test_auto_detect' => true,
      ),
      'properties' => 
      array (
        'creator' => '',
        'lastModifiedBy' => '',
        'title' => '',
        'description' => '',
        'subject' => '',
        'keywords' => '',
        'category' => '',
        'manager' => '',
        'company' => '',
      ),
    ),
    'imports' => 
    array (
      'read_only' => true,
      'ignore_empty' => false,
      'heading_row' => 
      array (
        'formatter' => 'slug',
      ),
      'csv' => 
      array (
        'delimiter' => NULL,
        'enclosure' => '"',
        'escape_character' => '\\',
        'contiguous' => false,
        'input_encoding' => 'UTF-8',
      ),
      'properties' => 
      array (
        'creator' => '',
        'lastModifiedBy' => '',
        'title' => '',
        'description' => '',
        'subject' => '',
        'keywords' => '',
        'category' => '',
        'manager' => '',
        'company' => '',
      ),
    ),
    'extension_detector' => 
    array (
      'xlsx' => 'Xlsx',
      'xlsm' => 'Xlsx',
      'xltx' => 'Xlsx',
      'xltm' => 'Xlsx',
      'xls' => 'Xls',
      'xlt' => 'Xls',
      'ods' => 'Ods',
      'ots' => 'Ods',
      'slk' => 'Slk',
      'xml' => 'Xml',
      'gnumeric' => 'Gnumeric',
      'htm' => 'Html',
      'html' => 'Html',
      'csv' => 'Csv',
      'tsv' => 'Csv',
      'pdf' => 'Dompdf',
    ),
    'value_binder' => 
    array (
      'default' => 'Maatwebsite\\Excel\\DefaultValueBinder',
    ),
    'cache' => 
    array (
      'driver' => 'memory',
      'batch' => 
      array (
        'memory_limit' => 60000,
      ),
      'illuminate' => 
      array (
        'store' => NULL,
      ),
    ),
    'transactions' => 
    array (
      'handler' => 'db',
      'db' => 
      array (
        'connection' => NULL,
      ),
    ),
    'temporary_files' => 
    array (
      'local_path' => 'C:\\xampp\\htdocs\\bagisto\\storage\\framework/cache/laravel-excel',
      'remote_disk' => NULL,
      'remote_prefix' => NULL,
      'force_resync_remote' => NULL,
    ),
  ),
  'filesystems' => 
  array (
    'default' => 'public',
    'cloud' => 's3',
    'disks' => 
    array (
      'local' => 
      array (
        'driver' => 'local',
        'root' => 'C:\\xampp\\htdocs\\bagisto\\storage\\app',
      ),
      'private' => 
      array (
        'driver' => 'local',
        'root' => 'C:\\xampp\\htdocs\\bagisto\\storage\\app/private',
      ),
      'public' => 
      array (
        'driver' => 'local',
        'root' => 'C:\\xampp\\htdocs\\bagisto\\storage\\app/public',
        'url' => 'http://localhost/storage',
        'visibility' => 'public',
      ),
      's3' => 
      array (
        'driver' => 's3',
        'key' => NULL,
        'secret' => NULL,
        'region' => NULL,
        'bucket' => NULL,
        'url' => NULL,
      ),
    ),
  ),
  'flare' => 
  array (
    'key' => NULL,
    'flare_middleware' => 
    array (
      0 => 'Spatie\\FlareClient\\FlareMiddleware\\RemoveRequestIp',
      1 => 'Spatie\\FlareClient\\FlareMiddleware\\AddGitInformation',
      2 => 'Spatie\\LaravelIgnition\\FlareMiddleware\\AddNotifierName',
      3 => 'Spatie\\LaravelIgnition\\FlareMiddleware\\AddEnvironmentInformation',
      4 => 'Spatie\\LaravelIgnition\\FlareMiddleware\\AddExceptionInformation',
      5 => 'Spatie\\LaravelIgnition\\FlareMiddleware\\AddDumps',
      'Spatie\\LaravelIgnition\\FlareMiddleware\\AddLogs' => 
      array (
        'maximum_number_of_collected_logs' => 200,
      ),
      'Spatie\\LaravelIgnition\\FlareMiddleware\\AddQueries' => 
      array (
        'maximum_number_of_collected_queries' => 200,
        'report_query_bindings' => true,
      ),
      'Spatie\\LaravelIgnition\\FlareMiddleware\\AddJobs' => 
      array (
        'max_chained_job_reporting_depth' => 5,
      ),
      'Spatie\\FlareClient\\FlareMiddleware\\CensorRequestBodyFields' => 
      array (
        'censor_fields' => 
        array (
          0 => 'password',
          1 => 'password_confirmation',
        ),
      ),
      'Spatie\\FlareClient\\FlareMiddleware\\CensorRequestHeaders' => 
      array (
        'headers' => 
        array (
          0 => 'API-KEY',
        ),
      ),
    ),
    'send_logs_as_events' => true,
  ),
  'hashing' => 
  array (
    'driver' => 'bcrypt',
    'bcrypt' => 
    array (
      'rounds' => 10,
    ),
    'argon' => 
    array (
      'memory' => 1024,
      'threads' => 2,
      'time' => 2,
    ),
  ),
  'ignition' => 
  array (
    'editor' => 'phpstorm',
    'theme' => 'auto',
    'enable_share_button' => true,
    'register_commands' => false,
    'solution_providers' => 
    array (
      0 => 'Spatie\\Ignition\\Solutions\\SolutionProviders\\BadMethodCallSolutionProvider',
      1 => 'Spatie\\Ignition\\Solutions\\SolutionProviders\\MergeConflictSolutionProvider',
      2 => 'Spatie\\Ignition\\Solutions\\SolutionProviders\\UndefinedPropertySolutionProvider',
      3 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\IncorrectValetDbCredentialsSolutionProvider',
      4 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\MissingAppKeySolutionProvider',
      5 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\DefaultDbNameSolutionProvider',
      6 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\TableNotFoundSolutionProvider',
      7 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\MissingImportSolutionProvider',
      8 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\InvalidRouteActionSolutionProvider',
      9 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\ViewNotFoundSolutionProvider',
      10 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\RunningLaravelDuskInProductionProvider',
      11 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\MissingColumnSolutionProvider',
      12 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\UnknownValidationSolutionProvider',
      13 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\MissingMixManifestSolutionProvider',
      14 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\MissingViteManifestSolutionProvider',
      15 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\MissingLivewireComponentSolutionProvider',
      16 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\UndefinedViewVariableSolutionProvider',
      17 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\GenericLaravelExceptionSolutionProvider',
      18 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\OpenAiSolutionProvider',
    ),
    'ignored_solution_providers' => 
    array (
    ),
    'enable_runnable_solutions' => NULL,
    'remote_sites_path' => 'C:\\xampp\\htdocs\\bagisto',
    'local_sites_path' => '',
    'housekeeping_endpoint_prefix' => '_ignition',
    'settings_file_path' => '',
    'recorders' => 
    array (
      0 => 'Spatie\\LaravelIgnition\\Recorders\\DumpRecorder\\DumpRecorder',
      1 => 'Spatie\\LaravelIgnition\\Recorders\\JobRecorder\\JobRecorder',
      2 => 'Spatie\\LaravelIgnition\\Recorders\\LogRecorder\\LogRecorder',
      3 => 'Spatie\\LaravelIgnition\\Recorders\\QueryRecorder\\QueryRecorder',
    ),
    'open_ai_key' => NULL,
    'with_stack_frame_arguments' => true,
    'argument_reducers' => 
    array (
      0 => 'Spatie\\Backtrace\\Arguments\\Reducers\\BaseTypeArgumentReducer',
      1 => 'Spatie\\Backtrace\\Arguments\\Reducers\\ArrayArgumentReducer',
      2 => 'Spatie\\Backtrace\\Arguments\\Reducers\\StdClassArgumentReducer',
      3 => 'Spatie\\Backtrace\\Arguments\\Reducers\\EnumArgumentReducer',
      4 => 'Spatie\\Backtrace\\Arguments\\Reducers\\ClosureArgumentReducer',
      5 => 'Spatie\\Backtrace\\Arguments\\Reducers\\DateTimeArgumentReducer',
      6 => 'Spatie\\Backtrace\\Arguments\\Reducers\\DateTimeZoneArgumentReducer',
      7 => 'Spatie\\Backtrace\\Arguments\\Reducers\\SymphonyRequestArgumentReducer',
      8 => 'Spatie\\LaravelIgnition\\ArgumentReducers\\ModelArgumentReducer',
      9 => 'Spatie\\LaravelIgnition\\ArgumentReducers\\CollectionArgumentReducer',
      10 => 'Spatie\\Backtrace\\Arguments\\Reducers\\StringableArgumentReducer',
    ),
  ),
  'image' => 
  array (
    'driver' => 'gd',
  ),
  'imagecache' => 
  array (
    'route' => 'cache',
    'paths' => 
    array (
      0 => 'C:\\xampp\\htdocs\\bagisto\\storage\\app/public',
      1 => 'C:\\xampp\\htdocs\\bagisto\\public\\storage',
    ),
    'templates' => 
    array (
      'small' => 'Webkul\\Shop\\CacheFilters\\Small',
      'medium' => 'Webkul\\Shop\\CacheFilters\\Medium',
      'large' => 'Webkul\\Shop\\CacheFilters\\Large',
    ),
    'lifetime' => 525600,
  ),
  'logging' => 
  array (
    'default' => 'stack',
    'channels' => 
    array (
      'stack' => 
      array (
        'driver' => 'stack',
        'channels' => 
        array (
          0 => 'single',
        ),
      ),
      'single' => 
      array (
        'driver' => 'single',
        'path' => 'C:\\xampp\\htdocs\\bagisto\\storage\\logs/laravel.log',
        'level' => 'debug',
      ),
      'daily' => 
      array (
        'driver' => 'daily',
        'path' => 'C:\\xampp\\htdocs\\bagisto\\storage\\logs/laravel.log',
        'level' => 'debug',
        'days' => 7,
      ),
      'slack' => 
      array (
        'driver' => 'slack',
        'url' => NULL,
        'username' => 'Laravel Log',
        'emoji' => ':boom:',
        'level' => 'critical',
      ),
      'stderr' => 
      array (
        'driver' => 'monolog',
        'handler' => 'Monolog\\Handler\\StreamHandler',
        'with' => 
        array (
          'stream' => 'php://stderr',
        ),
      ),
      'syslog' => 
      array (
        'driver' => 'syslog',
        'level' => 'debug',
      ),
      'errorlog' => 
      array (
        'driver' => 'errorlog',
        'level' => 'debug',
      ),
    ),
  ),
  'mail' => 
  array (
    'default' => 'smtp',
    'mailers' => 
    array (
      'smtp' => 
      array (
        'transport' => 'smtp',
        'host' => 'smtp.mailtrap.io',
        'port' => '2525',
        'encryption' => 'tls',
        'username' => '',
        'password' => '',
        'timeout' => NULL,
        'verify_peer' => false,
      ),
      'ses' => 
      array (
        'transport' => 'ses',
      ),
      'mailgun' => 
      array (
        'transport' => 'mailgun',
      ),
      'postmark' => 
      array (
        'transport' => 'postmark',
      ),
      'sendmail' => 
      array (
        'transport' => 'sendmail',
        'path' => '/usr/sbin/sendmail -bs -i',
      ),
      'log' => 
      array (
        'transport' => 'log',
        'channel' => NULL,
      ),
      'array' => 
      array (
        'transport' => 'array',
      ),
      'failover' => 
      array (
        'transport' => 'failover',
        'mailers' => 
        array (
          0 => 'smtp',
          1 => 'log',
        ),
      ),
    ),
    'from' => 
    array (
      'address' => 'shop@example.com',
      'name' => '',
    ),
    'admin' => 
    array (
      'address' => '',
      'name' => '',
    ),
    'markdown' => 
    array (
      'theme' => 'default',
      'paths' => 
      array (
        0 => 'C:\\xampp\\htdocs\\bagisto\\resources\\views/vendor/mail',
      ),
    ),
  ),
  'octane' => 
  array (
    'server' => 'roadrunner',
    'https' => false,
    'listeners' => 
    array (
      'Laravel\\Octane\\Events\\WorkerStarting' => 
      array (
        0 => 'Laravel\\Octane\\Listeners\\EnsureUploadedFilesAreValid',
        1 => 'Laravel\\Octane\\Listeners\\EnsureUploadedFilesCanBeMoved',
      ),
      'Laravel\\Octane\\Events\\RequestReceived' => 
      array (
        0 => 'Laravel\\Octane\\Listeners\\CreateConfigurationSandbox',
        1 => 'Laravel\\Octane\\Listeners\\GiveNewApplicationInstanceToAuthorizationGate',
        2 => 'Laravel\\Octane\\Listeners\\GiveNewApplicationInstanceToBroadcastManager',
        3 => 'Laravel\\Octane\\Listeners\\GiveNewApplicationInstanceToDatabaseManager',
        4 => 'Laravel\\Octane\\Listeners\\GiveNewApplicationInstanceToDatabaseSessionHandler',
        5 => 'Laravel\\Octane\\Listeners\\GiveNewApplicationInstanceToFilesystemManager',
        6 => 'Laravel\\Octane\\Listeners\\GiveNewApplicationInstanceToHttpKernel',
        7 => 'Laravel\\Octane\\Listeners\\GiveNewApplicationInstanceToMailManager',
        8 => 'Laravel\\Octane\\Listeners\\GiveNewApplicationInstanceToNotificationChannelManager',
        9 => 'Laravel\\Octane\\Listeners\\GiveNewApplicationInstanceToPipelineHub',
        10 => 'Laravel\\Octane\\Listeners\\GiveNewApplicationInstanceToCacheManager',
        11 => 'Laravel\\Octane\\Listeners\\GiveNewApplicationInstanceToSessionManager',
        12 => 'Laravel\\Octane\\Listeners\\GiveNewApplicationInstanceToQueueManager',
        13 => 'Laravel\\Octane\\Listeners\\GiveNewApplicationInstanceToRouter',
        14 => 'Laravel\\Octane\\Listeners\\GiveNewApplicationInstanceToValidationFactory',
        15 => 'Laravel\\Octane\\Listeners\\GiveNewApplicationInstanceToViewFactory',
        16 => 'Laravel\\Octane\\Listeners\\FlushDatabaseRecordModificationState',
        17 => 'Laravel\\Octane\\Listeners\\FlushDatabaseQueryLog',
        18 => 'Laravel\\Octane\\Listeners\\RefreshQueryDurationHandling',
        19 => 'Laravel\\Octane\\Listeners\\FlushLogContext',
        20 => 'Laravel\\Octane\\Listeners\\FlushArrayCache',
        21 => 'Laravel\\Octane\\Listeners\\FlushMonologState',
        22 => 'Laravel\\Octane\\Listeners\\FlushStrCache',
        23 => 'Laravel\\Octane\\Listeners\\FlushTranslatorCache',
        24 => 'Laravel\\Octane\\Listeners\\PrepareInertiaForNextOperation',
        25 => 'Laravel\\Octane\\Listeners\\PrepareLivewireForNextOperation',
        26 => 'Laravel\\Octane\\Listeners\\PrepareScoutForNextOperation',
        27 => 'Laravel\\Octane\\Listeners\\PrepareSocialiteForNextOperation',
        28 => 'Laravel\\Octane\\Listeners\\FlushLocaleState',
        29 => 'Laravel\\Octane\\Listeners\\FlushQueuedCookies',
        30 => 'Laravel\\Octane\\Listeners\\FlushSessionState',
        31 => 'Laravel\\Octane\\Listeners\\FlushAuthenticationState',
        32 => 'Laravel\\Octane\\Listeners\\EnforceRequestScheme',
        33 => 'Laravel\\Octane\\Listeners\\EnsureRequestServerPortMatchesScheme',
        34 => 'Laravel\\Octane\\Listeners\\GiveNewRequestInstanceToApplication',
        35 => 'Laravel\\Octane\\Listeners\\GiveNewRequestInstanceToPaginator',
      ),
      'Laravel\\Octane\\Events\\RequestHandled' => 
      array (
      ),
      'Laravel\\Octane\\Events\\RequestTerminated' => 
      array (
      ),
      'Laravel\\Octane\\Events\\TaskReceived' => 
      array (
        0 => 'Laravel\\Octane\\Listeners\\CreateConfigurationSandbox',
        1 => 'Laravel\\Octane\\Listeners\\GiveNewApplicationInstanceToAuthorizationGate',
        2 => 'Laravel\\Octane\\Listeners\\GiveNewApplicationInstanceToBroadcastManager',
        3 => 'Laravel\\Octane\\Listeners\\GiveNewApplicationInstanceToDatabaseManager',
        4 => 'Laravel\\Octane\\Listeners\\GiveNewApplicationInstanceToDatabaseSessionHandler',
        5 => 'Laravel\\Octane\\Listeners\\GiveNewApplicationInstanceToFilesystemManager',
        6 => 'Laravel\\Octane\\Listeners\\GiveNewApplicationInstanceToHttpKernel',
        7 => 'Laravel\\Octane\\Listeners\\GiveNewApplicationInstanceToMailManager',
        8 => 'Laravel\\Octane\\Listeners\\GiveNewApplicationInstanceToNotificationChannelManager',
        9 => 'Laravel\\Octane\\Listeners\\GiveNewApplicationInstanceToPipelineHub',
        10 => 'Laravel\\Octane\\Listeners\\GiveNewApplicationInstanceToCacheManager',
        11 => 'Laravel\\Octane\\Listeners\\GiveNewApplicationInstanceToSessionManager',
        12 => 'Laravel\\Octane\\Listeners\\GiveNewApplicationInstanceToQueueManager',
        13 => 'Laravel\\Octane\\Listeners\\GiveNewApplicationInstanceToRouter',
        14 => 'Laravel\\Octane\\Listeners\\GiveNewApplicationInstanceToValidationFactory',
        15 => 'Laravel\\Octane\\Listeners\\GiveNewApplicationInstanceToViewFactory',
        16 => 'Laravel\\Octane\\Listeners\\FlushDatabaseRecordModificationState',
        17 => 'Laravel\\Octane\\Listeners\\FlushDatabaseQueryLog',
        18 => 'Laravel\\Octane\\Listeners\\RefreshQueryDurationHandling',
        19 => 'Laravel\\Octane\\Listeners\\FlushLogContext',
        20 => 'Laravel\\Octane\\Listeners\\FlushArrayCache',
        21 => 'Laravel\\Octane\\Listeners\\FlushMonologState',
        22 => 'Laravel\\Octane\\Listeners\\FlushStrCache',
        23 => 'Laravel\\Octane\\Listeners\\FlushTranslatorCache',
        24 => 'Laravel\\Octane\\Listeners\\PrepareInertiaForNextOperation',
        25 => 'Laravel\\Octane\\Listeners\\PrepareLivewireForNextOperation',
        26 => 'Laravel\\Octane\\Listeners\\PrepareScoutForNextOperation',
        27 => 'Laravel\\Octane\\Listeners\\PrepareSocialiteForNextOperation',
      ),
      'Laravel\\Octane\\Events\\TaskTerminated' => 
      array (
      ),
      'Laravel\\Octane\\Events\\TickReceived' => 
      array (
        0 => 'Laravel\\Octane\\Listeners\\CreateConfigurationSandbox',
        1 => 'Laravel\\Octane\\Listeners\\GiveNewApplicationInstanceToAuthorizationGate',
        2 => 'Laravel\\Octane\\Listeners\\GiveNewApplicationInstanceToBroadcastManager',
        3 => 'Laravel\\Octane\\Listeners\\GiveNewApplicationInstanceToDatabaseManager',
        4 => 'Laravel\\Octane\\Listeners\\GiveNewApplicationInstanceToDatabaseSessionHandler',
        5 => 'Laravel\\Octane\\Listeners\\GiveNewApplicationInstanceToFilesystemManager',
        6 => 'Laravel\\Octane\\Listeners\\GiveNewApplicationInstanceToHttpKernel',
        7 => 'Laravel\\Octane\\Listeners\\GiveNewApplicationInstanceToMailManager',
        8 => 'Laravel\\Octane\\Listeners\\GiveNewApplicationInstanceToNotificationChannelManager',
        9 => 'Laravel\\Octane\\Listeners\\GiveNewApplicationInstanceToPipelineHub',
        10 => 'Laravel\\Octane\\Listeners\\GiveNewApplicationInstanceToCacheManager',
        11 => 'Laravel\\Octane\\Listeners\\GiveNewApplicationInstanceToSessionManager',
        12 => 'Laravel\\Octane\\Listeners\\GiveNewApplicationInstanceToQueueManager',
        13 => 'Laravel\\Octane\\Listeners\\GiveNewApplicationInstanceToRouter',
        14 => 'Laravel\\Octane\\Listeners\\GiveNewApplicationInstanceToValidationFactory',
        15 => 'Laravel\\Octane\\Listeners\\GiveNewApplicationInstanceToViewFactory',
        16 => 'Laravel\\Octane\\Listeners\\FlushDatabaseRecordModificationState',
        17 => 'Laravel\\Octane\\Listeners\\FlushDatabaseQueryLog',
        18 => 'Laravel\\Octane\\Listeners\\RefreshQueryDurationHandling',
        19 => 'Laravel\\Octane\\Listeners\\FlushLogContext',
        20 => 'Laravel\\Octane\\Listeners\\FlushArrayCache',
        21 => 'Laravel\\Octane\\Listeners\\FlushMonologState',
        22 => 'Laravel\\Octane\\Listeners\\FlushStrCache',
        23 => 'Laravel\\Octane\\Listeners\\FlushTranslatorCache',
        24 => 'Laravel\\Octane\\Listeners\\PrepareInertiaForNextOperation',
        25 => 'Laravel\\Octane\\Listeners\\PrepareLivewireForNextOperation',
        26 => 'Laravel\\Octane\\Listeners\\PrepareScoutForNextOperation',
        27 => 'Laravel\\Octane\\Listeners\\PrepareSocialiteForNextOperation',
      ),
      'Laravel\\Octane\\Events\\TickTerminated' => 
      array (
      ),
      'Laravel\\Octane\\Contracts\\OperationTerminated' => 
      array (
        0 => 'Laravel\\Octane\\Listeners\\FlushTemporaryContainerInstances',
      ),
      'Laravel\\Octane\\Events\\WorkerErrorOccurred' => 
      array (
        0 => 'Laravel\\Octane\\Listeners\\ReportException',
        1 => 'Laravel\\Octane\\Listeners\\StopWorkerIfNecessary',
      ),
      'Laravel\\Octane\\Events\\WorkerStopping' => 
      array (
      ),
    ),
    'warm' => 
    array (
      0 => 'auth',
      1 => 'cache',
      2 => 'cache.store',
      3 => 'config',
      4 => 'cookie',
      5 => 'db',
      6 => 'db.factory',
      7 => 'db.transactions',
      8 => 'encrypter',
      9 => 'files',
      10 => 'hash',
      11 => 'log',
      12 => 'router',
      13 => 'routes',
      14 => 'session',
      15 => 'session.store',
      16 => 'translator',
      17 => 'url',
      18 => 'view',
    ),
    'flush' => 
    array (
    ),
    'cache' => 
    array (
      'rows' => 1000,
      'bytes' => 10000,
    ),
    'tables' => 
    array (
      'example:1000' => 
      array (
        'name' => 'string:1000',
        'votes' => 'int',
      ),
    ),
    'watch' => 
    array (
      0 => 'app',
      1 => 'bootstrap',
      2 => 'config',
      3 => 'database',
      4 => 'public/**/*.php',
      5 => 'resources/**/*.php',
      6 => 'routes',
      7 => 'composer.lock',
      8 => '.env',
    ),
    'garbage' => 50,
    'max_execution_time' => 30,
  ),
  'products' => 
  array (
    'skipAttributesOnCopy' => 
    array (
    ),
    'linkProductsOnCopy' => false,
    'isSaleable' => NULL,
  ),
  'queue' => 
  array (
    'default' => 'sync',
    'connections' => 
    array (
      'sync' => 
      array (
        'driver' => 'sync',
      ),
      'database' => 
      array (
        'driver' => 'database',
        'table' => 'jobs',
        'queue' => 'default',
        'retry_after' => 90,
      ),
      'beanstalkd' => 
      array (
        'driver' => 'beanstalkd',
        'host' => 'localhost',
        'queue' => 'default',
        'retry_after' => 90,
      ),
      'sqs' => 
      array (
        'driver' => 'sqs',
        'key' => 'your-public-key',
        'secret' => 'your-secret-key',
        'prefix' => 'https://sqs.us-east-1.amazonaws.com/your-account-id',
        'queue' => 'your-queue-name',
        'region' => 'us-east-1',
      ),
      'redis' => 
      array (
        'driver' => 'redis',
        'connection' => 'default',
        'queue' => 'default',
        'retry_after' => 90,
        'block_for' => NULL,
      ),
    ),
    'failed' => 
    array (
      'driver' => 'database-uuids',
      'database' => 'mysql',
      'table' => 'failed_jobs',
    ),
  ),
  'repository' => 
  array (
    'pagination' => 
    array (
      'limit' => 15,
    ),
    'fractal' => 
    array (
      'params' => 
      array (
        'include' => 'include',
      ),
      'serializer' => 'League\\Fractal\\Serializer\\DataArraySerializer',
    ),
    'cache' => 
    array (
      'enabled' => false,
      'minutes' => 10080,
      'repository' => 'cache',
      'clean' => 
      array (
        'enabled' => true,
        'on' => 
        array (
          'created' => true,
          'updated' => true,
          'deleted' => true,
        ),
      ),
      'params' => 
      array (
        'skipCache' => 'skipCache',
      ),
      'allowed' => 
      array (
        'only' => NULL,
        'except' => NULL,
      ),
      'repositories' => 
      array (
        'Webkul\\Core\\Repositories\\CoreConfigRepository' => 
        array (
          'enabled' => true,
        ),
        'Webkul\\Core\\Repositories\\ChannelRepository' => 
        array (
          'enabled' => true,
        ),
        'Webkul\\Core\\Repositories\\CountryRepository' => 
        array (
          'enabled' => true,
        ),
        'Webkul\\Core\\Repositories\\CountryStateRepository' => 
        array (
          'enabled' => true,
        ),
        'Webkul\\Core\\Repositories\\CurrencyRepository' => 
        array (
          'enabled' => true,
        ),
        'Webkul\\Core\\Repositories\\LocaleRepository' => 
        array (
          'enabled' => true,
        ),
      ),
    ),
    'criteria' => 
    array (
      'acceptedConditions' => 
      array (
        0 => '=',
        1 => 'like',
        2 => 'in',
      ),
      'params' => 
      array (
        'search' => 'search',
        'searchFields' => 'searchFields',
        'filter' => 'filter',
        'orderBy' => 'orderBy',
        'sortedBy' => 'sortedBy',
        'with' => 'with',
        'searchJoin' => 'searchJoin',
        'withCount' => 'withCount',
      ),
    ),
    'generator' => 
    array (
      'basePath' => 'C:\\xampp\\htdocs\\bagisto\\app',
      'rootNamespace' => 'App\\',
      'stubsOverridePath' => 'C:\\xampp\\htdocs\\bagisto\\app',
      'paths' => 
      array (
        'models' => 'Entities',
        'repositories' => 'Repositories',
        'interfaces' => 'Repositories',
        'transformers' => 'Transformers',
        'presenters' => 'Presenters',
        'validators' => 'Validators',
        'controllers' => 'Http/Controllers',
        'provider' => 'RepositoryServiceProvider',
        'criteria' => 'Criteria',
      ),
    ),
  ),
  'responsecache' => 
  array (
    'enabled' => false,
    'cache_profile' => 'Spatie\\ResponseCache\\CacheProfiles\\CacheAllSuccessfulGetRequests',
    'cache_bypass_header' => 
    array (
      'name' => NULL,
      'value' => NULL,
    ),
    'cache_lifetime_in_seconds' => 604800,
    'add_cache_time_header' => true,
    'cache_time_header_name' => 'laravel-responsecache',
    'add_cache_age_header' => false,
    'cache_age_header_name' => 'laravel-responsecache-age',
    'cache_store' => 'file',
    'replacers' => 
    array (
      0 => 'Spatie\\ResponseCache\\Replacers\\CsrfTokenReplacer',
    ),
    'cache_tag' => '',
    'hasher' => 'Webkul\\FPC\\Hasher\\DefaultHasher',
    'serializer' => 'Spatie\\ResponseCache\\Serializers\\DefaultSerializer',
  ),
  'sanctum' => 
  array (
    'stateful' => 
    array (
      0 => 'localhost',
      1 => 'localhost:3000',
      2 => '127.0.0.1',
      3 => '127.0.0.1:8000',
      4 => '::1',
      5 => 'localhost',
    ),
    'guard' => 
    array (
    ),
    'expiration' => NULL,
    'middleware' => 
    array (
      'verify_csrf_token' => 'App\\Http\\Middleware\\VerifyCsrfToken',
      'encrypt_cookies' => 'App\\Http\\Middleware\\EncryptCookies',
    ),
  ),
  'scout' => 
  array (
    'driver' => NULL,
    'prefix' => '',
    'queue' => false,
    'after_commit' => false,
    'chunk' => 
    array (
      'searchable' => 500,
      'unsearchable' => 500,
    ),
    'soft_delete' => false,
    'identify' => false,
    'algolia' => 
    array (
      'id' => '',
      'secret' => '',
    ),
  ),
  'services' => 
  array (
    'mailgun' => 
    array (
      'domain' => NULL,
      'secret' => NULL,
    ),
    'ses' => 
    array (
      'key' => NULL,
      'secret' => NULL,
      'region' => 'us-east-1',
    ),
    'sparkpost' => 
    array (
      'secret' => NULL,
    ),
    'exchange_api' => 
    array (
      'default' => 'exchange_rates',
      'fixer' => 
      array (
        'key' => '',
        'class' => 'Webkul\\Core\\Helpers\\Exchange\\FixerExchange',
      ),
      'exchange_rates' => 
      array (
        'key' => '',
        'class' => 'Webkul\\Core\\Helpers\\Exchange\\ExchangeRates',
        'url' => '',
      ),
    ),
    'stripe' => 
    array (
      'model' => 'App\\User',
      'key' => NULL,
      'secret' => NULL,
    ),
    'facebook' => 
    array (
      'client_id' => '',
      'client_secret' => '',
      'redirect' => 'https://yourhost.com/customer/social-login/facebook/callback',
    ),
    'twitter' => 
    array (
      'client_id' => '',
      'client_secret' => '',
      'redirect' => 'https://yourhost.com/customer/social-login/twitter/callback',
    ),
    'google' => 
    array (
      'client_id' => '',
      'client_secret' => '',
      'redirect' => 'https://yourhost.com/customer/social-login/google/callback',
    ),
    'linkedin' => 
    array (
      'client_id' => '',
      'client_secret' => '',
      'redirect' => 'https://yourhost.com/customer/social-login/linkedin/callback',
    ),
    'github' => 
    array (
      'client_id' => '',
      'client_secret' => '',
      'redirect' => 'https://yourhost.com/customer/social-login/github/callback',
    ),
  ),
  'session' => 
  array (
    'driver' => 'file',
    'lifetime' => '120',
    'expire_on_close' => true,
    'encrypt' => false,
    'files' => 'C:\\xampp\\htdocs\\bagisto\\storage\\framework/sessions',
    'connection' => 'session',
    'table' => 'sessions',
    'store' => NULL,
    'lottery' => 
    array (
      0 => 2,
      1 => 100,
    ),
    'cookie' => 'bagisto_session',
    'path' => '/',
    'domain' => NULL,
    'secure' => NULL,
    'http_only' => true,
    'same_site' => NULL,
  ),
  'sitemap' => 
  array (
    'guzzle_options' => 
    array (
      'cookies' => true,
      'connect_timeout' => 10,
      'timeout' => 10,
      'allow_redirects' => false,
    ),
    'execute_javascript' => false,
    'chrome_binary_path' => NULL,
    'crawl_profile' => 'Spatie\\Sitemap\\Crawler\\Profile',
  ),
  'themes' => 
  array (
    'default' => 'default',
    'themes' => 
    array (
      'default' => 
      array (
        'name' => 'Default',
        'assets_path' => 'public/themes/shop/default',
        'views_path' => 'resources/themes/default/views',
        'vite' => 
        array (
          'hot_file' => 'shop-default-vite.hot',
          'build_directory' => 'themes/shop/default/build',
          'package_assets_directory' => 'src/Resources/assets',
        ),
      ),
    ),
    'admin-default' => 'default',
    'admin-themes' => 
    array (
      'default' => 
      array (
        'name' => 'Default',
        'assets_path' => 'public/themes/admin/default',
        'views_path' => 'resources/admin-themes/default/views',
        'vite' => 
        array (
          'hot_file' => 'admin-default-vite.hot',
          'build_directory' => 'themes/admin/default/build',
          'package_assets_directory' => 'src/Resources/assets',
        ),
      ),
    ),
  ),
  'tinker' => 
  array (
    'commands' => 
    array (
    ),
    'alias' => 
    array (
    ),
    'dont_alias' => 
    array (
      0 => 'App\\Nova',
    ),
  ),
  'translatable' => 
  array (
    'locales' => 
    array (
      0 => 'en',
      1 => 'fr',
      'es' => 
      array (
        0 => 'MX',
        1 => 'CO',
      ),
    ),
    'locale_separator' => '-',
    'locale' => NULL,
    'use_fallback' => true,
    'use_property_fallback' => true,
    'fallback_locale' => 'en',
    'translation_model_namespace' => NULL,
    'translation_suffix' => 'Translation',
    'locale_key' => 'locale',
    'to_array_always_loads_translations' => true,
    'rule_factory' => 
    array (
      'format' => 1,
      'prefix' => '%',
      'suffix' => '%',
    ),
  ),
  'view' => 
  array (
    'tracer' => false,
    'paths' => 
    array (
      0 => 'C:\\xampp\\htdocs\\bagisto\\resources\\views',
    ),
    'compiled' => 'C:\\xampp\\htdocs\\bagisto\\storage\\framework\\views',
  ),
  'visitor' => 
  array (
    'default' => 'jenssegers',
    'except' => 
    array (
      0 => 'login',
      1 => 'register',
    ),
    'table_name' => 'visits',
    'drivers' => 
    array (
      'jenssegers' => 'Shetabit\\Visitor\\Drivers\\JenssegersAgent',
      'UAParser' => 'Shetabit\\Visitor\\Drivers\\UAParser',
    ),
  ),
  'menu' => 
  array (
    'admin' => 
    array (
      0 => 
      array (
        'key' => 'dashboard',
        'name' => 'admin::app.components.layouts.sidebar.dashboard',
        'route' => 'admin.dashboard.index',
        'sort' => 1,
        'icon' => 'icon-dashboard',
      ),
      1 => 
      array (
        'key' => 'sales',
        'name' => 'admin::app.components.layouts.sidebar.sales',
        'route' => 'admin.sales.orders.index',
        'sort' => 2,
        'icon' => 'icon-sales',
      ),
      2 => 
      array (
        'key' => 'sales.orders',
        'name' => 'admin::app.components.layouts.sidebar.orders',
        'route' => 'admin.sales.orders.index',
        'sort' => 1,
        'icon' => '',
      ),
      3 => 
      array (
        'key' => 'sales.shipments',
        'name' => 'admin::app.components.layouts.sidebar.shipments',
        'route' => 'admin.sales.shipments.index',
        'sort' => 2,
        'icon' => '',
      ),
      4 => 
      array (
        'key' => 'sales.invoices',
        'name' => 'admin::app.components.layouts.sidebar.invoices',
        'route' => 'admin.sales.invoices.index',
        'sort' => 3,
        'icon' => '',
      ),
      5 => 
      array (
        'key' => 'sales.refunds',
        'name' => 'admin::app.components.layouts.sidebar.refunds',
        'route' => 'admin.sales.refunds.index',
        'sort' => 4,
        'icon' => '',
      ),
      6 => 
      array (
        'key' => 'sales.transactions',
        'name' => 'admin::app.components.layouts.sidebar.transactions',
        'route' => 'admin.sales.transactions.index',
        'sort' => 5,
        'icon' => '',
      ),
      7 => 
      array (
        'key' => 'catalog',
        'name' => 'admin::app.components.layouts.sidebar.catalog',
        'route' => 'admin.catalog.products.index',
        'sort' => 3,
        'icon' => 'icon-product',
      ),
      8 => 
      array (
        'key' => 'catalog.products',
        'name' => 'admin::app.components.layouts.sidebar.products',
        'route' => 'admin.catalog.products.index',
        'sort' => 1,
        'icon' => '',
      ),
      9 => 
      array (
        'key' => 'catalog.categories',
        'name' => 'admin::app.components.layouts.sidebar.categories',
        'route' => 'admin.catalog.categories.index',
        'sort' => 2,
        'icon' => '',
      ),
      10 => 
      array (
        'key' => 'catalog.attributes',
        'name' => 'admin::app.components.layouts.sidebar.attributes',
        'route' => 'admin.catalog.attributes.index',
        'sort' => 3,
        'icon' => '',
      ),
      11 => 
      array (
        'key' => 'catalog.families',
        'name' => 'admin::app.components.layouts.sidebar.attribute-families',
        'route' => 'admin.catalog.families.index',
        'sort' => 4,
        'icon' => '',
      ),
      12 => 
      array (
        'key' => 'customers',
        'name' => 'admin::app.components.layouts.sidebar.customers',
        'route' => 'admin.customers.customers.index',
        'sort' => 4,
        'icon' => 'icon-customer-2',
      ),
      13 => 
      array (
        'key' => 'customers.customers',
        'name' => 'admin::app.components.layouts.sidebar.customers',
        'route' => 'admin.customers.customers.index',
        'sort' => 1,
        'icon' => '',
      ),
      14 => 
      array (
        'key' => 'customers.groups',
        'name' => 'admin::app.components.layouts.sidebar.groups',
        'route' => 'admin.customers.groups.index',
        'sort' => 2,
        'icon' => '',
      ),
      15 => 
      array (
        'key' => 'customers.reviews',
        'name' => 'admin::app.components.layouts.sidebar.reviews',
        'route' => 'admin.customers.customers.review.index',
        'sort' => 3,
        'icon' => '',
      ),
      16 => 
      array (
        'key' => 'cms',
        'name' => 'admin::app.components.layouts.sidebar.cms',
        'route' => 'admin.cms.index',
        'sort' => 5,
        'icon' => 'icon-cms',
      ),
      17 => 
      array (
        'key' => 'marketing',
        'name' => 'admin::app.components.layouts.sidebar.marketing',
        'route' => 'admin.marketing.promotions.catalog_rules.index',
        'sort' => 6,
        'icon' => 'icon-promotion',
        'icon-class' => 'promotion-icon',
      ),
      18 => 
      array (
        'key' => 'marketing.promotions',
        'name' => 'admin::app.components.layouts.sidebar.promotions',
        'route' => 'admin.marketing.promotions.catalog_rules.index',
        'sort' => 1,
        'icon' => '',
      ),
      19 => 
      array (
        'key' => 'marketing.promotions.catalog-rules',
        'name' => 'admin::app.marketing.promotions.index.catalog-rule-title',
        'route' => 'admin.marketing.promotions.catalog_rules.index',
        'sort' => 1,
        'icon' => '',
      ),
      20 => 
      array (
        'key' => 'marketing.promotions.cart-rules',
        'name' => 'admin::app.marketing.promotions.index.cart-rule-title',
        'route' => 'admin.marketing.promotions.cart_rules.index',
        'sort' => 2,
        'icon' => '',
      ),
      21 => 
      array (
        'key' => 'marketing.communications',
        'name' => 'admin::app.components.layouts.sidebar.communications',
        'route' => 'admin.marketing.communications.email_templates.index',
        'sort' => 2,
        'icon' => '',
      ),
      22 => 
      array (
        'key' => 'marketing.communications.email-templates',
        'name' => 'admin::app.components.layouts.sidebar.email-templates',
        'route' => 'admin.marketing.communications.email_templates.index',
        'sort' => 1,
        'icon' => '',
      ),
      23 => 
      array (
        'key' => 'marketing.communications.events',
        'name' => 'admin::app.components.layouts.sidebar.events',
        'route' => 'admin.marketing.communications.events.index',
        'sort' => 2,
        'icon' => '',
      ),
      24 => 
      array (
        'key' => 'marketing.communications.campaigns',
        'name' => 'admin::app.components.layouts.sidebar.campaigns',
        'route' => 'admin.marketing.communications.campaigns.index',
        'sort' => 2,
        'icon' => '',
      ),
      25 => 
      array (
        'key' => 'marketing.communications.subscribers',
        'name' => 'admin::app.components.layouts.sidebar.newsletter-subscriptions',
        'route' => 'admin.marketing.communications.subscribers.index',
        'sort' => 3,
        'icon' => '',
      ),
      26 => 
      array (
        'key' => 'marketing.sitemaps',
        'name' => 'admin::app.components.layouts.sidebar.sitemaps',
        'route' => 'admin.marketing.promotions.sitemaps.index',
        'sort' => 3,
        'icon' => '',
      ),
      27 => 
      array (
        'key' => 'reporting',
        'name' => 'admin::app.components.layouts.sidebar.reporting',
        'route' => 'admin.reporting.sales.index',
        'sort' => 7,
        'icon' => 'icon-report',
        'icon-class' => 'report-icon',
      ),
      28 => 
      array (
        'key' => 'reporting.sales',
        'name' => 'admin::app.components.layouts.sidebar.sales',
        'route' => 'admin.reporting.sales.index',
        'sort' => 1,
        'icon' => '',
      ),
      29 => 
      array (
        'key' => 'reporting.customers',
        'name' => 'admin::app.components.layouts.sidebar.customers',
        'route' => 'admin.reporting.customers.index',
        'sort' => 2,
        'icon' => '',
      ),
      30 => 
      array (
        'key' => 'reporting.products',
        'name' => 'admin::app.components.layouts.sidebar.products',
        'route' => 'admin.reporting.products.index',
        'sort' => 3,
        'icon' => '',
      ),
      31 => 
      array (
        'key' => 'settings',
        'name' => 'admin::app.components.layouts.sidebar.settings',
        'route' => 'admin.settings.locales.index',
        'sort' => 8,
        'icon' => 'icon-settings',
        'icon-class' => 'settings-icon',
      ),
      32 => 
      array (
        'key' => 'settings.locales',
        'name' => 'admin::app.components.layouts.sidebar.locales',
        'route' => 'admin.settings.locales.index',
        'sort' => 1,
        'icon' => '',
      ),
      33 => 
      array (
        'key' => 'settings.currencies',
        'name' => 'admin::app.components.layouts.sidebar.currencies',
        'route' => 'admin.settings.currencies.index',
        'sort' => 2,
        'icon' => '',
      ),
      34 => 
      array (
        'key' => 'settings.exchange_rates',
        'name' => 'admin::app.components.layouts.sidebar.exchange-rates',
        'route' => 'admin.settings.exchange_rates.index',
        'sort' => 3,
        'icon' => '',
      ),
      35 => 
      array (
        'key' => 'settings.inventory_sources',
        'name' => 'admin::app.components.layouts.sidebar.inventory-sources',
        'route' => 'admin.settings.inventory_sources.index',
        'sort' => 4,
        'icon' => '',
      ),
      36 => 
      array (
        'key' => 'settings.channels',
        'name' => 'admin::app.components.layouts.sidebar.channels',
        'route' => 'admin.settings.channels.index',
        'sort' => 5,
        'icon' => '',
      ),
      37 => 
      array (
        'key' => 'settings.users',
        'name' => 'admin::app.components.layouts.sidebar.users',
        'route' => 'admin.settings.users.index',
        'sort' => 6,
        'icon' => '',
      ),
      38 => 
      array (
        'key' => 'settings.roles',
        'name' => 'admin::app.components.layouts.sidebar.roles',
        'route' => 'admin.settings.roles.index',
        'sort' => 7,
        'icon' => '',
      ),
      39 => 
      array (
        'key' => 'settings.themes',
        'name' => 'Themes',
        'route' => 'admin.settings.themes.index',
        'sort' => 8,
        'icon' => '',
      ),
      40 => 
      array (
        'key' => 'settings.taxes',
        'name' => 'admin::app.components.layouts.sidebar.taxes',
        'route' => 'admin.settings.taxes.categories.index',
        'sort' => 9,
        'icon' => '',
      ),
      41 => 
      array (
        'key' => 'settings.taxes.tax-categories',
        'name' => 'admin::app.components.layouts.sidebar.tax-categories',
        'route' => 'admin.settings.taxes.categories.index',
        'sort' => 1,
        'icon' => '',
      ),
      42 => 
      array (
        'key' => 'settings.taxes.tax-rates',
        'name' => 'admin::app.components.layouts.sidebar.tax-rates',
        'route' => 'admin.settings.taxes.rates.index',
        'sort' => 2,
        'icon' => '',
      ),
      43 => 
      array (
        'key' => 'configuration',
        'name' => 'admin::app.components.layouts.sidebar.configure',
        'route' => 'admin.configuration.index',
        'sort' => 9,
        'icon' => 'icon-configuration',
      ),
    ),
    'customer' => 
    array (
      0 => 
      array (
        'key' => 'account',
        'name' => 'shop::app.layouts.my-account',
        'route' => 'shop.customers.account.profile.index',
        'icon' => '',
        'sort' => 1,
      ),
      1 => 
      array (
        'key' => 'account.profile',
        'name' => 'shop::app.layouts.profile',
        'route' => 'shop.customers.account.profile.index',
        'icon' => 'icon-users',
        'sort' => 1,
      ),
      2 => 
      array (
        'key' => 'account.address',
        'name' => 'shop::app.layouts.address',
        'route' => 'shop.customers.account.addresses.index',
        'icon' => 'icon-location',
        'sort' => 2,
      ),
      3 => 
      array (
        'key' => 'account.orders',
        'name' => 'shop::app.layouts.orders',
        'route' => 'shop.customers.account.orders.index',
        'icon' => 'icon-orders',
        'sort' => 3,
      ),
      4 => 
      array (
        'key' => 'account.downloadables',
        'name' => 'shop::app.layouts.downloadable-products',
        'route' => 'shop.customers.account.downloadable_products.index',
        'icon' => 'icon-download',
        'sort' => 4,
      ),
      5 => 
      array (
        'key' => 'account.reviews',
        'name' => 'shop::app.layouts.reviews',
        'route' => 'shop.customers.account.reviews.index',
        'icon' => 'icon-star',
        'sort' => 5,
      ),
      6 => 
      array (
        'key' => 'account.wishlist',
        'name' => 'shop::app.layouts.wishlist',
        'route' => 'shop.customers.account.wishlist.index',
        'icon' => 'icon-heart',
        'sort' => 6,
      ),
    ),
  ),
  'acl' => 
  array (
    0 => 
    array (
      'key' => 'dashboard',
      'name' => 'admin::app.acl.dashboard',
      'route' => 'admin.dashboard.index',
      'sort' => 1,
    ),
    1 => 
    array (
      'key' => 'sales',
      'name' => 'admin::app.acl.sales',
      'route' => 'admin.sales.orders.index',
      'sort' => 2,
    ),
    2 => 
    array (
      'key' => 'sales.orders',
      'name' => 'admin::app.acl.orders',
      'route' => 'admin.sales.orders.index',
      'sort' => 1,
    ),
    3 => 
    array (
      'key' => 'sales.orders.view',
      'name' => 'admin::app.acl.view',
      'route' => 'admin.sales.orders.view',
      'sort' => 1,
    ),
    4 => 
    array (
      'key' => 'sales.orders.cancel',
      'name' => 'admin::app.acl.cancel',
      'route' => 'admin.sales.orders.cancel',
      'sort' => 2,
    ),
    5 => 
    array (
      'key' => 'sales.invoices',
      'name' => 'admin::app.acl.invoices',
      'route' => 'admin.sales.invoices.index',
      'sort' => 2,
    ),
    6 => 
    array (
      'key' => 'sales.invoices.view',
      'name' => 'admin::app.acl.view',
      'route' => 'admin.sales.invoices.view',
      'sort' => 1,
    ),
    7 => 
    array (
      'key' => 'sales.invoices.create',
      'name' => 'admin::app.acl.create',
      'route' => 'admin.sales.invoices.create',
      'sort' => 2,
    ),
    8 => 
    array (
      'key' => 'sales.shipments',
      'name' => 'admin::app.acl.shipments',
      'route' => 'admin.sales.shipments.index',
      'sort' => 3,
    ),
    9 => 
    array (
      'key' => 'sales.shipments.view',
      'name' => 'admin::app.acl.view',
      'route' => 'admin.sales.shipments.view',
      'sort' => 1,
    ),
    10 => 
    array (
      'key' => 'sales.shipments.create',
      'name' => 'admin::app.acl.create',
      'route' => 'admin.sales.shipments.create',
      'sort' => 2,
    ),
    11 => 
    array (
      'key' => 'sales.refunds',
      'name' => 'admin::app.acl.refunds',
      'route' => 'admin.sales.refunds.index',
      'sort' => 4,
    ),
    12 => 
    array (
      'key' => 'sales.refunds.view',
      'name' => 'admin::app.acl.view',
      'route' => 'admin.sales.refunds.view',
      'sort' => 1,
    ),
    13 => 
    array (
      'key' => 'sales.refunds.create',
      'name' => 'admin::app.acl.create',
      'route' => 'admin.sales.refunds.create',
      'sort' => 2,
    ),
    14 => 
    array (
      'key' => 'sales.transactions',
      'name' => 'admin::app.acl.transactions',
      'route' => 'admin.sales.transactions.index',
      'sort' => 5,
    ),
    15 => 
    array (
      'key' => 'sales.transactions.view',
      'name' => 'admin::app.acl.view',
      'route' => 'admin.sales.transactions.view',
      'sort' => 1,
    ),
    16 => 
    array (
      'key' => 'catalog',
      'name' => 'admin::app.acl.catalog',
      'route' => 'admin.catalog.index',
      'sort' => 3,
    ),
    17 => 
    array (
      'key' => 'catalog.products',
      'name' => 'admin::app.acl.products',
      'route' => 'admin.catalog.products.index',
      'sort' => 1,
    ),
    18 => 
    array (
      'key' => 'catalog.products.create',
      'name' => 'admin::app.acl.create',
      'route' => 'admin.catalog.products.create',
      'sort' => 1,
    ),
    19 => 
    array (
      'key' => 'catalog.products.copy',
      'name' => 'admin::app.acl.copy',
      'route' => 'admin.catalog.products.copy',
      'sort' => 2,
    ),
    20 => 
    array (
      'key' => 'catalog.products.edit',
      'name' => 'admin::app.acl.edit',
      'route' => 'admin.catalog.products.edit',
      'sort' => 3,
    ),
    21 => 
    array (
      'key' => 'catalog.products.delete',
      'name' => 'admin::app.acl.delete',
      'route' => 'admin.catalog.products.delete',
      'sort' => 4,
    ),
    22 => 
    array (
      'key' => 'catalog.products.mass-update',
      'name' => 'admin::app.acl.mass-update',
      'route' => 'admin.catalog.products.mass_update',
      'sort' => 5,
    ),
    23 => 
    array (
      'key' => 'catalog.products.mass-delete',
      'name' => 'admin::app.acl.mass-delete',
      'route' => 'admin.catalog.products.mass_delete',
      'sort' => 6,
    ),
    24 => 
    array (
      'key' => 'catalog.categories',
      'name' => 'admin::app.acl.categories',
      'route' => 'admin.catalog.categories.index',
      'sort' => 2,
    ),
    25 => 
    array (
      'key' => 'catalog.categories.create',
      'name' => 'admin::app.acl.create',
      'route' => 'admin.catalog.categories.create',
      'sort' => 1,
    ),
    26 => 
    array (
      'key' => 'catalog.categories.edit',
      'name' => 'admin::app.acl.edit',
      'route' => 'admin.catalog.categories.edit',
      'sort' => 2,
    ),
    27 => 
    array (
      'key' => 'catalog.categories.delete',
      'name' => 'admin::app.acl.delete',
      'route' => 'admin.catalog.categories.delete',
      'sort' => 3,
    ),
    28 => 
    array (
      'key' => 'catalog.categories.mass-delete',
      'name' => 'admin::app.acl.mass-delete',
      'route' => 'admin.catalog.categories.mass_delete',
      'sort' => 4,
    ),
    29 => 
    array (
      'key' => 'catalog.categories.mass-update',
      'name' => 'admin::app.acl.mass-update',
      'route' => 'admin.catalog.categories.mass_update',
      'sort' => 4,
    ),
    30 => 
    array (
      'key' => 'catalog.attributes',
      'name' => 'admin::app.acl.attributes',
      'route' => 'admin.catalog.attributes.index',
      'sort' => 3,
    ),
    31 => 
    array (
      'key' => 'catalog.attributes.create',
      'name' => 'admin::app.acl.create',
      'route' => 'admin.catalog.attributes.create',
      'sort' => 1,
    ),
    32 => 
    array (
      'key' => 'catalog.attributes.edit',
      'name' => 'admin::app.acl.edit',
      'route' => 'admin.catalog.attributes.edit',
      'sort' => 2,
    ),
    33 => 
    array (
      'key' => 'catalog.attributes.delete',
      'name' => 'admin::app.acl.delete',
      'route' => 'admin.catalog.attributes.delete',
      'sort' => 3,
    ),
    34 => 
    array (
      'key' => 'catalog.attributes.mass-delete',
      'name' => 'admin::app.acl.mass-delete',
      'route' => 'admin.catalog.attributes.mass_delete',
      'sort' => 4,
    ),
    35 => 
    array (
      'key' => 'catalog.families',
      'name' => 'admin::app.acl.attribute-families',
      'route' => 'admin.catalog.families.index',
      'sort' => 4,
    ),
    36 => 
    array (
      'key' => 'catalog.families.create',
      'name' => 'admin::app.acl.create',
      'route' => 'admin.catalog.families.create',
      'sort' => 1,
    ),
    37 => 
    array (
      'key' => 'catalog.families.edit',
      'name' => 'admin::app.acl.edit',
      'route' => 'admin.catalog.families.edit',
      'sort' => 2,
    ),
    38 => 
    array (
      'key' => 'catalog.families.delete',
      'name' => 'admin::app.acl.delete',
      'route' => 'admin.catalog.families.delete',
      'sort' => 3,
    ),
    39 => 
    array (
      'key' => 'customers',
      'name' => 'admin::app.acl.customers',
      'route' => 'admin.customers.customers.index',
      'sort' => 4,
    ),
    40 => 
    array (
      'key' => 'customers.customers',
      'name' => 'admin::app.acl.customers',
      'route' => 'admin.customers.customers.index',
      'sort' => 1,
    ),
    41 => 
    array (
      'key' => 'customers.customers.create',
      'name' => 'admin::app.acl.create',
      'route' => 'admin.customer.create',
      'sort' => 1,
    ),
    42 => 
    array (
      'key' => 'customers.customers.edit',
      'name' => 'admin::app.acl.edit',
      'route' => 'admin.customers.customers.edit',
      'sort' => 2,
    ),
    43 => 
    array (
      'key' => 'customers.customers.delete',
      'name' => 'admin::app.acl.delete',
      'route' => 'admin.customers.customers.delete',
      'sort' => 3,
    ),
    44 => 
    array (
      'key' => 'customers.customers.mass-update',
      'name' => 'admin::app.acl.mass-update',
      'route' => 'admin.customers.customers.mass_update',
      'sort' => 4,
    ),
    45 => 
    array (
      'key' => 'customers.customers.mass-delete',
      'name' => 'admin::app.acl.mass-delete',
      'route' => 'admin.customers.customers.mass_delete',
      'sort' => 5,
    ),
    46 => 
    array (
      'key' => 'customers.addresses',
      'name' => 'admin::app.acl.addresses',
      'route' => 'admin.customers.customers.addresses.index',
      'sort' => 2,
    ),
    47 => 
    array (
      'key' => 'customers.addresses.create',
      'name' => 'admin::app.acl.create',
      'route' => 'admin.customers.customers.addresses.create',
      'sort' => 1,
    ),
    48 => 
    array (
      'key' => 'customers.addresses.edit',
      'name' => 'admin::app.acl.edit',
      'route' => 'admin.customers.customers.addresses.edit',
      'sort' => 2,
    ),
    49 => 
    array (
      'key' => 'customers.addresses.delete',
      'name' => 'admin::app.acl.delete',
      'route' => 'admin.customers.customers.addresses.delete',
      'sort' => 3,
    ),
    50 => 
    array (
      'key' => 'customers.note',
      'name' => 'admin::app.acl.note',
      'route' => 'admin.customer.note.create',
      'sort' => 3,
    ),
    51 => 
    array (
      'key' => 'customers.groups',
      'name' => 'admin::app.acl.groups',
      'route' => 'admin.customers.groups.index',
      'sort' => 4,
    ),
    52 => 
    array (
      'key' => 'customers.groups.create',
      'name' => 'admin::app.acl.create',
      'route' => 'admin.groups.create',
      'sort' => 1,
    ),
    53 => 
    array (
      'key' => 'customers.groups.edit',
      'name' => 'admin::app.acl.edit',
      'route' => 'admin.customers.groups.update',
      'sort' => 2,
    ),
    54 => 
    array (
      'key' => 'customers.groups.delete',
      'name' => 'admin::app.acl.delete',
      'route' => 'admin.customers.groups.delete',
      'sort' => 3,
    ),
    55 => 
    array (
      'key' => 'customers.reviews',
      'name' => 'admin::app.acl.reviews',
      'route' => 'admin.customers.customers.review.index',
      'sort' => 5,
    ),
    56 => 
    array (
      'key' => 'customers.reviews.edit',
      'name' => 'admin::app.acl.edit',
      'route' => 'admin.customers.customers.review.edit',
      'sort' => 1,
    ),
    57 => 
    array (
      'key' => 'customers.reviews.delete',
      'name' => 'admin::app.acl.delete',
      'route' => 'admin.customers.customers.review.delete',
      'sort' => 2,
    ),
    58 => 
    array (
      'key' => 'customers.reviews.mass-update',
      'name' => 'admin::app.acl.mass-update',
      'route' => 'admin.customers.customers.review.mass_update',
      'sort' => 3,
    ),
    59 => 
    array (
      'key' => 'customers.reviews.mass-delete',
      'name' => 'admin::app.acl.mass-delete',
      'route' => 'admin.customers.customers.review.mass_delete',
      'sort' => 4,
    ),
    60 => 
    array (
      'key' => 'customers.orders',
      'name' => 'admin::app.acl.orders',
      'route' => 'admin.customers.customers.orders.data',
      'sort' => 7,
    ),
    61 => 
    array (
      'key' => 'marketing',
      'name' => 'admin::app.acl.marketing',
      'route' => 'admin.marketing.promotions.cart_rules.index',
      'sort' => 6,
    ),
    62 => 
    array (
      'key' => 'marketing.promotions',
      'name' => 'admin::app.acl.promotions',
      'route' => 'admin.marketing.promotions.cart_rules.index',
      'sort' => 1,
    ),
    63 => 
    array (
      'key' => 'marketing.promotions.cart-rules',
      'name' => 'admin::app.acl.cart-rules',
      'route' => 'admin.marketing.promotions.cart_rules.index',
      'sort' => 1,
    ),
    64 => 
    array (
      'key' => 'marketing.promotions.cart-rules.create',
      'name' => 'admin::app.acl.create',
      'route' => 'admin.marketing.promotions.cart_rules.create',
      'sort' => 1,
    ),
    65 => 
    array (
      'key' => 'marketing.promotions.cart-rules.copy',
      'name' => 'admin::app.acl.copy',
      'route' => 'admin.marketing.promotions.cart_rules.copy',
      'sort' => 1,
    ),
    66 => 
    array (
      'key' => 'marketing.promotions.cart-rules.edit',
      'name' => 'admin::app.acl.edit',
      'route' => 'admin.marketing.promotions.cart_rules.edit',
      'sort' => 2,
    ),
    67 => 
    array (
      'key' => 'marketing.promotions.cart-rules.delete',
      'name' => 'admin::app.acl.delete',
      'route' => 'admin.marketing.promotions.cart_rules.delete',
      'sort' => 3,
    ),
    68 => 
    array (
      'key' => 'marketing.promotions.catalog-rules',
      'name' => 'admin::app.acl.catalog-rules',
      'route' => 'admin.marketing.promotions.catalog_rules.index',
      'sort' => 1,
    ),
    69 => 
    array (
      'key' => 'marketing.promotions.catalog-rules.create',
      'name' => 'admin::app.acl.create',
      'route' => 'admin.marketing.promotions.catalog_rules.index',
      'sort' => 1,
    ),
    70 => 
    array (
      'key' => 'marketing.promotions.catalog-rules.edit',
      'name' => 'admin::app.acl.edit',
      'route' => 'admin.marketing.promotions.catalog_rules.edit',
      'sort' => 2,
    ),
    71 => 
    array (
      'key' => 'marketing.promotions.catalog-rules.delete',
      'name' => 'admin::app.acl.delete',
      'route' => 'admin.marketing.promotions.catalog_rules.delete',
      'sort' => 3,
    ),
    72 => 
    array (
      'key' => 'marketing.communications',
      'name' => 'admin::app.acl.communications',
      'route' => 'admin.marketing.communications.email_templates.index',
      'sort' => 2,
    ),
    73 => 
    array (
      'key' => 'marketing.communications.email-templates',
      'name' => 'admin::app.acl.email-templates',
      'route' => 'admin.marketing.communications.email_templates.index',
      'sort' => 1,
    ),
    74 => 
    array (
      'key' => 'marketing.communications.email-templates.create',
      'name' => 'admin::app.acl.create',
      'route' => 'admin.marketing.communications.email_templates.create',
      'sort' => 2,
    ),
    75 => 
    array (
      'key' => 'marketing.communications.email-templates.edit',
      'name' => 'admin::app.acl.edit',
      'route' => 'admin.marketing.communications.email_templates.edit',
      'sort' => 3,
    ),
    76 => 
    array (
      'key' => 'marketing.communications.email-templates.delete',
      'name' => 'admin::app.acl.delete',
      'route' => 'admin.marketing.communications.email_templates.delete',
      'sort' => 4,
    ),
    77 => 
    array (
      'key' => 'marketing.communications.events',
      'name' => 'admin::app.acl.events',
      'route' => 'admin.marketing.communications.events.index',
      'sort' => 2,
    ),
    78 => 
    array (
      'key' => 'marketing.communications.events.create',
      'name' => 'admin::app.acl.create',
      'route' => 'admin.marketing.communications.events.update',
      'sort' => 1,
    ),
    79 => 
    array (
      'key' => 'marketing.communications.events.edit',
      'name' => 'admin::app.acl.edit',
      'route' => 'admin.marketing.communications.events.edit',
      'sort' => 2,
    ),
    80 => 
    array (
      'key' => 'marketing.communications.events.delete',
      'name' => 'admin::app.acl.delete',
      'route' => 'admin.marketing.communications.events.delete',
      'sort' => 3,
    ),
    81 => 
    array (
      'key' => 'marketing.communications.campaigns',
      'name' => 'admin::app.acl.campaigns',
      'route' => 'admin.marketing.communications.campaigns.index',
      'sort' => 3,
    ),
    82 => 
    array (
      'key' => 'marketing.communications.campaigns.create',
      'name' => 'admin::app.acl.create',
      'route' => 'admin.marketing.communications.campaigns.create',
      'sort' => 1,
    ),
    83 => 
    array (
      'key' => 'marketing.communications.campaigns.edit',
      'name' => 'admin::app.acl.edit',
      'route' => 'admin.marketing.communications.campaigns.edit',
      'sort' => 2,
    ),
    84 => 
    array (
      'key' => 'marketing.communications.campaigns.delete',
      'name' => 'admin::app.acl.delete',
      'route' => 'admin.marketing.communications.campaigns.delete',
      'sort' => 3,
    ),
    85 => 
    array (
      'key' => 'marketing.communications.subscribers',
      'name' => 'admin::app.acl.subscribers',
      'route' => 'admin.marketing.communications.subscribers.index',
      'sort' => 3,
    ),
    86 => 
    array (
      'key' => 'marketing.communications.subscribers.edit',
      'name' => 'admin::app.acl.edit',
      'route' => 'admin.marketing.communications.subscribers.edit',
      'sort' => 1,
    ),
    87 => 
    array (
      'key' => 'marketing.communications.subscribers.delete',
      'name' => 'admin::app.acl.delete',
      'route' => 'admin.marketing.communications.subscribers.delete',
      'sort' => 2,
    ),
    88 => 
    array (
      'key' => 'marketing.sitemaps',
      'name' => 'admin::app.acl.sitemaps',
      'route' => 'admin.marketing.promotions.sitemaps.index',
      'sort' => 3,
    ),
    89 => 
    array (
      'key' => 'marketing.sitemaps.create',
      'name' => 'admin::app.acl.create',
      'route' => 'admin.marketing.promotions.sitemaps.update',
      'sort' => 1,
    ),
    90 => 
    array (
      'key' => 'marketing.sitemaps.edit',
      'name' => 'admin::app.acl.edit',
      'route' => 'admin.marketing.promotions.sitemaps.update',
      'sort' => 2,
    ),
    91 => 
    array (
      'key' => 'marketing.sitemaps.delete',
      'name' => 'admin::app.acl.delete',
      'route' => 'admin.marketing.promotions.sitemaps.delete',
      'sort' => 3,
    ),
    92 => 
    array (
      'key' => 'reporting',
      'name' => 'admin::app.acl.reporting',
      'route' => 'admin.reporting.sales.index',
      'sort' => 6,
    ),
    93 => 
    array (
      'key' => 'reporting.sales',
      'name' => 'admin::app.acl.sales',
      'route' => 'admin.reporting.sales.index',
      'sort' => 1,
    ),
    94 => 
    array (
      'key' => 'reporting.customers',
      'name' => 'admin::app.acl.customers',
      'route' => 'admin.reporting.customers.index',
      'sort' => 2,
    ),
    95 => 
    array (
      'key' => 'reporting.products',
      'name' => 'admin::app.acl.products',
      'route' => 'admin.reporting.products.index',
      'sort' => 3,
    ),
    96 => 
    array (
      'key' => 'cms',
      'name' => 'admin::app.acl.cms',
      'route' => 'admin.cms.index',
      'sort' => 7,
    ),
    97 => 
    array (
      'key' => 'cms.create',
      'name' => 'admin::app.acl.create',
      'route' => 'admin.cms.create',
      'sort' => 1,
    ),
    98 => 
    array (
      'key' => 'cms.edit',
      'name' => 'admin::app.acl.edit',
      'route' => 'admin.cms.edit',
      'sort' => 2,
    ),
    99 => 
    array (
      'key' => 'cms.delete',
      'name' => 'admin::app.acl.delete',
      'route' => 'admin.cms.delete',
      'sort' => 3,
    ),
    100 => 
    array (
      'key' => 'cms.mass-delete',
      'name' => 'admin::app.acl.mass-delete',
      'route' => 'admin.cms.mass_delete',
      'sort' => 4,
    ),
    101 => 
    array (
      'key' => 'settings',
      'name' => 'admin::app.acl.settings',
      'route' => 'admin.settings.users.index',
      'sort' => 8,
    ),
    102 => 
    array (
      'key' => 'settings.locales',
      'name' => 'admin::app.acl.locales',
      'route' => 'admin.settings.locales.index',
      'sort' => 1,
    ),
    103 => 
    array (
      'key' => 'settings.locales.create',
      'name' => 'admin::app.acl.create',
      'route' => 'admin.settings.locales.create',
      'sort' => 1,
    ),
    104 => 
    array (
      'key' => 'settings.locales.edit',
      'name' => 'admin::app.acl.edit',
      'route' => 'admin.settings.locales.edit',
      'sort' => 2,
    ),
    105 => 
    array (
      'key' => 'settings.locales.delete',
      'name' => 'admin::app.acl.delete',
      'route' => 'admin.settings.locales.delete',
      'sort' => 3,
    ),
    106 => 
    array (
      'key' => 'settings.currencies',
      'name' => 'admin::app.acl.currencies',
      'route' => 'admin.settings.currencies.index',
      'sort' => 2,
    ),
    107 => 
    array (
      'key' => 'settings.currencies.create',
      'name' => 'admin::app.acl.create',
      'route' => 'admin.settings.currencies.create',
      'sort' => 1,
    ),
    108 => 
    array (
      'key' => 'settings.currencies.edit',
      'name' => 'admin::app.acl.edit',
      'route' => 'admin.settings.currencies.edit',
      'sort' => 2,
    ),
    109 => 
    array (
      'key' => 'settings.currencies.delete',
      'name' => 'admin::app.acl.delete',
      'route' => 'admin.settings.currencies.delete',
      'sort' => 3,
    ),
    110 => 
    array (
      'key' => 'settings.exchange_rates',
      'name' => 'admin::app.acl.exchange-rates',
      'route' => 'admin.settings.exchange_rates.index',
      'sort' => 3,
    ),
    111 => 
    array (
      'key' => 'settings.exchange_rates.create',
      'name' => 'admin::app.acl.create',
      'route' => 'admin.settings.exchange_rates.create',
      'sort' => 1,
    ),
    112 => 
    array (
      'key' => 'settings.exchange_rates.edit',
      'name' => 'admin::app.acl.edit',
      'route' => 'admin.settings.exchange_rates.edit',
      'sort' => 2,
    ),
    113 => 
    array (
      'key' => 'settings.exchange_rates.delete',
      'name' => 'admin::app.acl.delete',
      'route' => 'admin.settings.exchange_rates.delete',
      'sort' => 3,
    ),
    114 => 
    array (
      'key' => 'settings.inventory_sources',
      'name' => 'admin::app.acl.inventory-sources',
      'route' => 'admin.settings.inventory_sources.index',
      'sort' => 4,
    ),
    115 => 
    array (
      'key' => 'settings.inventory_sources.create',
      'name' => 'admin::app.acl.create',
      'route' => 'admin.settings.inventory_sources.create',
      'sort' => 1,
    ),
    116 => 
    array (
      'key' => 'settings.inventory_sources.edit',
      'name' => 'admin::app.acl.edit',
      'route' => 'admin.settings.inventory_sources.edit',
      'sort' => 2,
    ),
    117 => 
    array (
      'key' => 'settings.inventory_sources.delete',
      'name' => 'admin::app.acl.delete',
      'route' => 'admin.settings.inventory_sources.delete',
      'sort' => 3,
    ),
    118 => 
    array (
      'key' => 'settings.channels',
      'name' => 'admin::app.acl.channels',
      'route' => 'admin.settings.channels.index',
      'sort' => 5,
    ),
    119 => 
    array (
      'key' => 'settings.channels.create',
      'name' => 'admin::app.acl.create',
      'route' => 'admin.settings.channels.create',
      'sort' => 1,
    ),
    120 => 
    array (
      'key' => 'settings.channels.edit',
      'name' => 'admin::app.acl.edit',
      'route' => 'admin.settings.channels.edit',
      'sort' => 2,
    ),
    121 => 
    array (
      'key' => 'settings.channels.delete',
      'name' => 'admin::app.acl.delete',
      'route' => 'admin.settings.channels.delete',
      'sort' => 3,
    ),
    122 => 
    array (
      'key' => 'settings.users',
      'name' => 'admin::app.acl.users',
      'route' => 'admin.settings.users.index',
      'sort' => 6,
    ),
    123 => 
    array (
      'key' => 'settings.users.users',
      'name' => 'admin::app.acl.users',
      'route' => 'admin.settings.users.index',
      'sort' => 1,
    ),
    124 => 
    array (
      'key' => 'settings.users.users.create',
      'name' => 'admin::app.acl.create',
      'route' => 'admin.settings.users.store',
      'sort' => 1,
    ),
    125 => 
    array (
      'key' => 'settings.users.users.edit',
      'name' => 'admin::app.acl.edit',
      'route' => 'admin.settings.users.edit',
      'sort' => 2,
    ),
    126 => 
    array (
      'key' => 'settings.users.users.delete',
      'name' => 'admin::app.acl.delete',
      'route' => 'admin.settings.users.delete',
      'sort' => 3,
    ),
    127 => 
    array (
      'key' => 'settings.roles',
      'name' => 'admin::app.acl.roles',
      'route' => 'admin.settings.roles.index',
      'sort' => 7,
    ),
    128 => 
    array (
      'key' => 'settings.roles.create',
      'name' => 'admin::app.acl.create',
      'route' => 'admin.settings.roles.create',
      'sort' => 1,
    ),
    129 => 
    array (
      'key' => 'settings.roles.edit',
      'name' => 'admin::app.acl.edit',
      'route' => 'admin.settings.roles.edit',
      'sort' => 2,
    ),
    130 => 
    array (
      'key' => 'settings.roles.delete',
      'name' => 'admin::app.acl.delete',
      'route' => 'admin.settings.roles.delete',
      'sort' => 3,
    ),
    131 => 
    array (
      'key' => 'settings.themes',
      'name' => 'admin::app.acl.themes',
      'route' => 'admin.settings.themes.index',
      'sort' => 8,
    ),
    132 => 
    array (
      'key' => 'settings.themes.create',
      'name' => 'admin::app.acl.create',
      'route' => 'admin.settings.themes.store',
      'sort' => 1,
    ),
    133 => 
    array (
      'key' => 'settings.themes.edit',
      'name' => 'admin::app.acl.edit',
      'route' => 'admin.settings.themes.edit',
      'sort' => 2,
    ),
    134 => 
    array (
      'key' => 'settings.themes.delete',
      'name' => 'admin::app.acl.delete',
      'route' => 'admin.settings.themes.delete',
      'sort' => 3,
    ),
    135 => 
    array (
      'key' => 'settings.taxes',
      'name' => 'admin::app.acl.taxes',
      'route' => 'admin.settings.taxes.categories.index',
      'sort' => 9,
    ),
    136 => 
    array (
      'key' => 'settings.taxes.tax-categories',
      'name' => 'admin::app.acl.tax-categories',
      'route' => 'admin.settings.taxes.categories.index',
      'sort' => 1,
    ),
    137 => 
    array (
      'key' => 'settings.taxes.tax-categories.create',
      'name' => 'admin::app.acl.create',
      'route' => 'admin.settings.taxes.tax_categories.create',
      'sort' => 1,
    ),
    138 => 
    array (
      'key' => 'settings.taxes.tax-categories.edit',
      'name' => 'admin::app.acl.edit',
      'route' => 'admin.settings.taxes.categories.edit',
      'sort' => 2,
    ),
    139 => 
    array (
      'key' => 'settings.taxes.tax-categories.delete',
      'name' => 'admin::app.acl.delete',
      'route' => 'admin.settings.taxes.categories.delete',
      'sort' => 3,
    ),
    140 => 
    array (
      'key' => 'settings.taxes.tax-rates',
      'name' => 'admin::app.acl.tax-rates',
      'route' => 'admin.settings.taxes.rates.index',
      'sort' => 2,
    ),
    141 => 
    array (
      'key' => 'settings.taxes.tax-rates.create',
      'name' => 'admin::app.acl.create',
      'route' => 'admin.settings.taxes.rates.create',
      'sort' => 1,
    ),
    142 => 
    array (
      'key' => 'settings.taxes.tax-rates.edit',
      'name' => 'admin::app.acl.edit',
      'route' => 'admin.settings.taxes.rates.edit',
      'sort' => 2,
    ),
    143 => 
    array (
      'key' => 'configuration',
      'name' => 'admin::app.acl.configure',
      'route' => 'admin.configuration.index',
      'sort' => 9,
    ),
  ),
  'core' => 
  array (
    0 => 
    array (
      'key' => 'general',
      'name' => 'admin::app.configuration.index.general.title',
      'info' => 'admin::app.configuration.index.general.info',
      'sort' => 1,
    ),
    1 => 
    array (
      'key' => 'general.general',
      'name' => 'admin::app.configuration.index.general.general.title',
      'info' => 'admin::app.configuration.index.general.general.info',
      'icon' => 'settings/store.svg',
      'sort' => 1,
    ),
    2 => 
    array (
      'key' => 'general.general.locale_options',
      'name' => 'admin::app.configuration.index.general.general.unit-options.title',
      'info' => 'admin::app.configuration.index.general.general.unit-options.title-info',
      'sort' => 1,
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'weight_unit',
          'title' => 'admin::app.configuration.index.general.general.unit-options.weight-unit',
          'type' => 'select',
          'options' => 
          array (
            0 => 
            array (
              'title' => 'lbs',
              'value' => 'lbs',
            ),
            1 => 
            array (
              'title' => 'kgs',
              'value' => 'kgs',
            ),
          ),
          'channel_based' => true,
        ),
      ),
    ),
    3 => 
    array (
      'key' => 'general.content',
      'name' => 'admin::app.configuration.index.general.content.title',
      'info' => 'admin::app.configuration.index.general.content.info',
      'icon' => 'settings/store.svg',
      'sort' => 2,
    ),
    4 => 
    array (
      'key' => 'general.content.shop',
      'name' => 'admin::app.configuration.index.general.content.settings.title',
      'info' => 'admin::app.configuration.index.general.content.settings.title-info',
      'sort' => 1,
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'compare_option',
          'title' => 'admin::app.configuration.index.general.content.settings.compare-options',
          'type' => 'boolean',
          'default' => '1',
          'locale_based' => true,
          'channel_based' => true,
        ),
        1 => 
        array (
          'name' => 'wishlist_option',
          'title' => 'admin::app.configuration.index.general.content.settings.wishlist-options',
          'type' => 'boolean',
          'default' => '1',
          'locale_based' => true,
          'channel_based' => true,
        ),
        2 => 
        array (
          'name' => 'image_search',
          'title' => 'admin::app.configuration.index.general.content.settings.image-search-option',
          'type' => 'boolean',
          'default' => '1',
          'locale_based' => true,
          'channel_based' => true,
        ),
      ),
    ),
    5 => 
    array (
      'key' => 'general.content.custom_scripts',
      'name' => 'admin::app.configuration.index.general.content.custom-scripts.title',
      'info' => 'admin::app.configuration.index.general.content.custom-scripts.title-info',
      'sort' => 1,
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'custom_css',
          'title' => 'admin::app.configuration.index.general.content.custom-scripts.custom-css',
          'type' => 'textarea',
          'channel_based' => true,
          'locale_based' => false,
        ),
        1 => 
        array (
          'name' => 'custom_javascript',
          'title' => 'admin::app.configuration.index.general.content.custom-scripts.custom-javascript',
          'type' => 'textarea',
          'channel_based' => true,
          'locale_based' => false,
        ),
      ),
    ),
    6 => 
    array (
      'key' => 'general.design',
      'name' => 'admin::app.configuration.index.general.design.title',
      'info' => 'admin::app.configuration.index.general.design.info',
      'icon' => 'settings/theme.svg',
      'sort' => 3,
    ),
    7 => 
    array (
      'key' => 'general.design.admin_logo',
      'name' => 'admin::app.configuration.index.general.design.admin-logo.title',
      'info' => 'admin::app.configuration.index.general.design.admin-logo.title-info',
      'sort' => 1,
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'logo_image',
          'title' => 'admin::app.configuration.index.general.design.admin-logo.logo-image',
          'type' => 'image',
          'channel_based' => true,
          'validation' => 'mimes:bmp,jpeg,jpg,png,webp',
        ),
        1 => 
        array (
          'name' => 'favicon',
          'title' => 'admin::app.configuration.index.general.design.admin-logo.favicon',
          'type' => 'image',
          'channel_based' => true,
          'validation' => 'mimes:bmp,jpeg,jpg,png,webp',
        ),
      ),
    ),
    8 => 
    array (
      'key' => 'catalog',
      'name' => 'admin::app.configuration.index.catalog.title',
      'info' => 'admin::app.configuration.index.catalog.info',
      'sort' => 2,
    ),
    9 => 
    array (
      'key' => 'catalog.inventory',
      'name' => 'admin::app.configuration.index.catalog.inventory.title',
      'info' => 'admin::app.configuration.index.catalog.inventory.info',
      'icon' => 'settings/store.svg',
      'sort' => 1,
    ),
    10 => 
    array (
      'key' => 'catalog.inventory.stock_options',
      'name' => 'admin::app.configuration.index.catalog.inventory.stock-options.title',
      'info' => 'admin::app.configuration.index.catalog.inventory.stock-options.title-info',
      'sort' => 1,
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'back_orders',
          'title' => 'admin::app.configuration.index.catalog.inventory.stock-options.allow-back-orders',
          'type' => 'boolean',
          'channel_based' => true,
        ),
      ),
    ),
    11 => 
    array (
      'key' => 'catalog.products',
      'name' => 'admin::app.configuration.index.catalog.products.title',
      'info' => 'admin::app.configuration.index.catalog.products.info',
      'icon' => 'settings/store-information.svg',
      'sort' => 2,
    ),
    12 => 
    array (
      'key' => 'catalog.products.guest_checkout',
      'name' => 'admin::app.configuration.index.catalog.products.guest-checkout.title',
      'info' => 'admin::app.configuration.index.catalog.products.guest-checkout.title-info',
      'sort' => 1,
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'allow_guest_checkout',
          'title' => 'admin::app.configuration.index.catalog.products.guest-checkout.allow-guest-checkout',
          'type' => 'boolean',
        ),
      ),
    ),
    13 => 
    array (
      'key' => 'catalog.products.product_view_page',
      'name' => 'admin::app.configuration.index.catalog.products.product-view-page.title',
      'info' => 'admin::app.configuration.index.catalog.products.product-view-page.title-info',
      'sort' => 3,
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'no_of_related_products',
          'title' => 'admin::app.configuration.index.catalog.products.product-view-page.allow-no-of-related-products',
          'type' => 'number',
          'validation' => 'min:0',
        ),
        1 => 
        array (
          'name' => 'no_of_up_sells_products',
          'title' => 'admin::app.configuration.index.catalog.products.product-view-page.allow-no-of-up-sells-products',
          'type' => 'number',
          'validation' => 'min:0',
        ),
      ),
    ),
    14 => 
    array (
      'key' => 'catalog.products.cart_view_page',
      'name' => 'admin::app.configuration.index.catalog.products.cart-view-page.title',
      'info' => 'admin::app.configuration.index.catalog.products.cart-view-page.title-info',
      'sort' => 3,
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'no_of_cross_sells_products',
          'title' => 'admin::app.configuration.index.catalog.products.cart-view-page.allow-no-of-cross-sells-products',
          'type' => 'number',
          'validation' => 'min:0',
        ),
      ),
    ),
    15 => 
    array (
      'key' => 'catalog.products.storefront',
      'name' => 'admin::app.configuration.index.catalog.products.storefront.title',
      'info' => 'admin::app.configuration.index.catalog.products.storefront.title-info',
      'sort' => 3,
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'search_mode',
          'title' => 'admin::app.configuration.index.catalog.products.storefront.search-mode',
          'type' => 'select',
          'options' => 
          array (
            0 => 
            array (
              'title' => 'admin::app.configuration.index.catalog.products.storefront.database',
              'value' => 'database',
            ),
            1 => 
            array (
              'title' => 'admin::app.configuration.index.catalog.products.storefront.elastic',
              'value' => 'elastic',
            ),
          ),
        ),
        1 => 
        array (
          'name' => 'mode',
          'title' => 'admin::app.configuration.index.catalog.products.storefront.default-list-mode',
          'type' => 'select',
          'options' => 
          array (
            0 => 
            array (
              'title' => 'admin::app.configuration.index.catalog.products.storefront.grid',
              'value' => 'grid',
            ),
            1 => 
            array (
              'title' => 'admin::app.configuration.index.catalog.products.storefront.list',
              'value' => 'list',
            ),
          ),
          'channel_based' => true,
        ),
        2 => 
        array (
          'name' => 'products_per_page',
          'title' => 'admin::app.configuration.index.catalog.products.storefront.products-per-page',
          'type' => 'text',
          'info' => 'admin::app.configuration.index.catalog.products.storefront.comma-separated',
          'channel_based' => true,
        ),
        3 => 
        array (
          'name' => 'sort_by',
          'title' => 'admin::app.configuration.index.catalog.products.storefront.sort-by',
          'type' => 'select',
          'options' => 
          array (
            0 => 
            array (
              'title' => 'admin::app.configuration.index.catalog.products.storefront.from-a-z',
              'value' => 'name-asc',
            ),
            1 => 
            array (
              'title' => 'admin::app.configuration.index.catalog.products.storefront.from-z-a',
              'value' => 'name-desc',
            ),
            2 => 
            array (
              'title' => 'admin::app.configuration.index.catalog.products.storefront.latest-first',
              'value' => 'created_at-desc',
            ),
            3 => 
            array (
              'title' => 'admin::app.configuration.index.catalog.products.storefront.oldest-first',
              'value' => 'created_at-asc',
            ),
            4 => 
            array (
              'title' => 'admin::app.configuration.index.catalog.products.storefront.cheapest-first',
              'value' => 'price-asc',
            ),
            5 => 
            array (
              'title' => 'admin::app.configuration.index.catalog.products.storefront.expensive-first',
              'value' => 'price-desc',
            ),
          ),
          'channel_based' => true,
        ),
        4 => 
        array (
          'name' => 'buy_now_button_display',
          'title' => 'admin::app.configuration.index.catalog.products.storefront.buy-now-button-display',
          'type' => 'boolean',
        ),
      ),
    ),
    16 => 
    array (
      'key' => 'catalog.products.cache_small_image',
      'name' => 'admin::app.configuration.index.catalog.products.small-image.title',
      'info' => 'admin::app.configuration.index.catalog.products.small-image.title-info',
      'sort' => 4,
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'width',
          'title' => 'admin::app.configuration.index.catalog.products.small-image.width',
          'type' => 'text',
        ),
        1 => 
        array (
          'name' => 'height',
          'title' => 'admin::app.configuration.index.catalog.products.small-image.height',
          'type' => 'text',
        ),
      ),
    ),
    17 => 
    array (
      'key' => 'catalog.products.cache_medium_image',
      'name' => 'admin::app.configuration.index.catalog.products.medium-image.title',
      'info' => 'admin::app.configuration.index.catalog.products.medium-image.title-info',
      'sort' => 5,
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'width',
          'title' => 'admin::app.configuration.index.catalog.products.medium-image.width',
          'type' => 'text',
        ),
        1 => 
        array (
          'name' => 'height',
          'title' => 'admin::app.configuration.index.catalog.products.medium-image.height',
          'type' => 'text',
        ),
      ),
    ),
    18 => 
    array (
      'key' => 'catalog.products.cache_large_image',
      'name' => 'admin::app.configuration.index.catalog.products.large-image.title',
      'info' => 'admin::app.configuration.index.catalog.products.large-image.title-info',
      'sort' => 6,
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'width',
          'title' => 'admin::app.configuration.index.catalog.products.large-image.width',
          'type' => 'text',
        ),
        1 => 
        array (
          'name' => 'height',
          'title' => 'admin::app.configuration.index.catalog.products.large-image.height',
          'type' => 'text',
        ),
      ),
    ),
    19 => 
    array (
      'key' => 'catalog.products.review',
      'name' => 'admin::app.configuration.index.catalog.products.review.title',
      'info' => 'admin::app.configuration.index.catalog.products.review.title-info',
      'sort' => 7,
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'guest_review',
          'title' => 'admin::app.configuration.index.catalog.products.review.allow-guest-review',
          'type' => 'boolean',
        ),
      ),
    ),
    20 => 
    array (
      'key' => 'catalog.products.attribute',
      'name' => 'admin::app.configuration.index.catalog.products.attribute.title',
      'info' => 'admin::app.configuration.index.catalog.products.attribute.title-info',
      'sort' => 8,
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'image_attribute_upload_size',
          'title' => 'admin::app.configuration.index.catalog.products.attribute.image-upload-size',
          'type' => 'text',
        ),
        1 => 
        array (
          'name' => 'file_attribute_upload_size',
          'title' => 'admin::app.configuration.index.catalog.products.attribute.file-upload-size',
          'type' => 'text',
        ),
      ),
    ),
    21 => 
    array (
      'key' => 'catalog.products.social_share',
      'name' => 'admin::app.configuration.index.catalog.products.social-share.title',
      'info' => 'admin::app.configuration.index.catalog.products.social-share.title-info',
      'sort' => 100,
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'enabled',
          'title' => 'admin::app.configuration.index.catalog.products.social-share.enable-social-share',
          'type' => 'boolean',
        ),
        1 => 
        array (
          'name' => 'facebook',
          'title' => 'admin::app.configuration.index.catalog.products.social-share.enable-share-facebook',
          'type' => 'boolean',
        ),
        2 => 
        array (
          'name' => 'twitter',
          'title' => 'admin::app.configuration.index.catalog.products.social-share.enable-share-twitter',
          'type' => 'boolean',
        ),
        3 => 
        array (
          'name' => 'pinterest',
          'title' => 'admin::app.configuration.index.catalog.products.social-share.enable-share-pinterest',
          'type' => 'boolean',
        ),
        4 => 
        array (
          'name' => 'whatsapp',
          'title' => 'admin::app.configuration.index.catalog.products.social-share.enable-share-whatsapp',
          'type' => 'boolean',
          'info' => 'What\'s App share link just will appear to mobile devices.',
        ),
        5 => 
        array (
          'name' => 'linkedin',
          'title' => 'admin::app.configuration.index.catalog.products.social-share.enable-share-linkedin',
          'type' => 'boolean',
        ),
        6 => 
        array (
          'name' => 'email',
          'title' => 'admin::app.configuration.index.catalog.products.social-share.enable-share-email',
          'type' => 'boolean',
        ),
        7 => 
        array (
          'name' => 'share_message',
          'title' => 'admin::app.configuration.index.catalog.products.social-share.share-message',
          'type' => 'text',
        ),
      ),
    ),
    22 => 
    array (
      'key' => 'catalog.rich_snippets',
      'name' => 'admin::app.configuration.index.catalog.rich-snippets.title',
      'info' => 'admin::app.configuration.index.catalog.rich-snippets.info',
      'icon' => 'settings/settings.svg',
      'sort' => 3,
    ),
    23 => 
    array (
      'key' => 'catalog.rich_snippets.products',
      'name' => 'admin::app.configuration.index.catalog.rich-snippets.products.title',
      'info' => 'admin::app.configuration.index.catalog.rich-snippets.products.title-info',
      'sort' => 1,
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'enable',
          'title' => 'admin::app.configuration.index.catalog.rich-snippets.products.enable',
          'type' => 'boolean',
        ),
        1 => 
        array (
          'name' => 'show_sku',
          'title' => 'admin::app.configuration.index.catalog.rich-snippets.products.show-sku',
          'type' => 'boolean',
        ),
        2 => 
        array (
          'name' => 'show_weight',
          'title' => 'admin::app.configuration.index.catalog.rich-snippets.products.show-weight',
          'type' => 'boolean',
        ),
        3 => 
        array (
          'name' => 'show_categories',
          'title' => 'admin::app.configuration.index.catalog.rich-snippets.products.show-categories',
          'type' => 'boolean',
        ),
        4 => 
        array (
          'name' => 'show_images',
          'title' => 'admin::app.configuration.index.catalog.rich-snippets.products.show-images',
          'type' => 'boolean',
        ),
        5 => 
        array (
          'name' => 'show_reviews',
          'title' => 'admin::app.configuration.index.catalog.rich-snippets.products.show-reviews',
          'type' => 'boolean',
        ),
        6 => 
        array (
          'name' => 'show_ratings',
          'title' => 'admin::app.configuration.index.catalog.rich-snippets.products.show-ratings',
          'type' => 'boolean',
        ),
        7 => 
        array (
          'name' => 'show_offers',
          'title' => 'admin::app.configuration.index.catalog.rich-snippets.products.show-offers',
          'type' => 'boolean',
        ),
      ),
    ),
    24 => 
    array (
      'key' => 'catalog.rich_snippets.categories',
      'name' => 'admin::app.configuration.index.catalog.rich-snippets.categories.title',
      'info' => 'admin::app.configuration.index.catalog.rich-snippets.categories.title-info',
      'sort' => 1,
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'enable',
          'title' => 'admin::app.configuration.index.catalog.rich-snippets.categories.enable',
          'type' => 'boolean',
        ),
        1 => 
        array (
          'name' => 'show_search_input_field',
          'title' => 'admin::app.configuration.index.catalog.rich-snippets.categories.show-search-input-field',
          'type' => 'boolean',
        ),
      ),
    ),
    25 => 
    array (
      'key' => 'customer',
      'name' => 'admin::app.configuration.index.customer.title',
      'info' => 'admin::app.configuration.index.customer.info',
      'sort' => 3,
    ),
    26 => 
    array (
      'key' => 'customer.address',
      'name' => 'admin::app.configuration.index.customer.address.title',
      'info' => 'admin::app.configuration.index.customer.address.info',
      'icon' => 'settings/address.svg',
      'sort' => 1,
    ),
    27 => 
    array (
      'key' => 'customer.address.requirements',
      'name' => 'admin::app.configuration.index.customer.address.requirements.title',
      'info' => 'admin::app.configuration.index.customer.address.requirements.title-info',
      'sort' => 1,
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'country',
          'title' => 'admin::app.configuration.index.customer.address.requirements.country',
          'type' => 'boolean',
          'channel_based' => true,
          'default' => '1',
        ),
        1 => 
        array (
          'name' => 'state',
          'title' => 'admin::app.configuration.index.customer.address.requirements.state',
          'type' => 'boolean',
          'channel_based' => true,
          'default' => '1',
        ),
        2 => 
        array (
          'name' => 'postcode',
          'title' => 'admin::app.configuration.index.customer.address.requirements.zip',
          'type' => 'boolean',
          'channel_based' => true,
          'default' => '1',
        ),
      ),
    ),
    28 => 
    array (
      'key' => 'customer.address.information',
      'name' => 'admin::app.configuration.index.customer.address.information.title',
      'info' => 'admin::app.configuration.index.customer.address.information.title-info',
      'sort' => 2,
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'street_lines',
          'title' => 'admin::app.configuration.index.customer.address.information.street-lines',
          'type' => 'text',
          'validation' => 'between:1,2',
          'channel_based' => true,
        ),
      ),
    ),
    29 => 
    array (
      'key' => 'customer.captcha',
      'name' => 'admin::app.configuration.index.customer.captcha.title',
      'info' => 'admin::app.configuration.index.customer.captcha.info',
      'icon' => 'settings/captcha.svg',
      'sort' => 2,
    ),
    30 => 
    array (
      'key' => 'customer.captcha.credentials',
      'name' => 'admin::app.configuration.index.customer.captcha.credentials.title',
      'info' => 'admin::app.configuration.index.customer.captcha.credentials.title-info',
      'sort' => 1,
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'site_key',
          'title' => 'admin::app.configuration.index.customer.captcha.credentials.site-key',
          'type' => 'text',
          'channel_based' => true,
        ),
        1 => 
        array (
          'name' => 'secret_key',
          'title' => 'admin::app.configuration.index.customer.captcha.credentials.secret-key',
          'type' => 'text',
          'channel_based' => true,
        ),
        2 => 
        array (
          'name' => 'status',
          'title' => 'admin::app.configuration.index.customer.captcha.credentials.status',
          'type' => 'boolean',
          'channel_based' => true,
        ),
      ),
    ),
    31 => 
    array (
      'key' => 'customer.settings',
      'name' => 'admin::app.configuration.index.customer.settings.title',
      'info' => 'admin::app.configuration.index.customer.settings.settings-info',
      'icon' => 'settings/settings.svg',
      'sort' => 3,
    ),
    32 => 
    array (
      'key' => 'customer.settings.newsletter',
      'name' => 'admin::app.configuration.index.customer.settings.newsletter.title',
      'info' => 'admin::app.configuration.index.customer.settings.newsletter.title-info',
      'sort' => 2,
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'subscription',
          'title' => 'admin::app.configuration.index.customer.settings.newsletter.subscription',
          'type' => 'boolean',
        ),
      ),
    ),
    33 => 
    array (
      'key' => 'customer.settings.email',
      'name' => 'admin::app.configuration.index.customer.settings.email.title',
      'info' => 'admin::app.configuration.index.customer.settings.email.title-info',
      'sort' => 3,
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'verification',
          'title' => 'admin::app.configuration.index.customer.settings.email.email-verification',
          'type' => 'boolean',
        ),
      ),
    ),
    34 => 
    array (
      'key' => 'customer.settings.social_login',
      'name' => 'admin::app.configuration.index.customer.settings.social-login.social-login',
      'info' => 'admin::app.configuration.index.customer.settings.social-login.social-login-info',
      'sort' => 4,
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'enable_facebook',
          'title' => 'admin::app.configuration.index.customer.settings.social-login.enable-facebook',
          'type' => 'boolean',
          'channel_based' => true,
        ),
        1 => 
        array (
          'name' => 'enable_twitter',
          'title' => 'admin::app.configuration.index.customer.settings.social-login.enable-twitter',
          'type' => 'boolean',
          'channel_based' => true,
        ),
        2 => 
        array (
          'name' => 'enable_google',
          'title' => 'admin::app.configuration.index.customer.settings.social-login.enable-google',
          'type' => 'boolean',
          'channel_based' => true,
        ),
        3 => 
        array (
          'name' => 'enable_linkedin',
          'title' => 'admin::app.configuration.index.customer.settings.social-login.enable-linkedin',
          'type' => 'boolean',
          'channel_based' => true,
        ),
        4 => 
        array (
          'name' => 'enable_github',
          'title' => 'admin::app.configuration.index.customer.settings.social-login.enable-github',
          'type' => 'boolean',
          'channel_based' => true,
        ),
      ),
    ),
    35 => 
    array (
      'key' => 'emails',
      'name' => 'admin::app.configuration.index.email.title',
      'info' => 'admin::app.configuration.index.email.info',
      'sort' => 4,
    ),
    36 => 
    array (
      'key' => 'emails.configure',
      'name' => 'admin::app.configuration.index.email.email-settings.title',
      'info' => 'admin::app.configuration.index.email.email-settings.info',
      'icon' => 'settings/email.svg',
      'sort' => 1,
    ),
    37 => 
    array (
      'key' => 'emails.configure.email_settings',
      'name' => 'admin::app.configuration.index.email.email-settings.title',
      'info' => 'admin::app.configuration.index.email.email-settings.info',
      'sort' => 1,
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'sender_name',
          'title' => 'admin::app.configuration.index.email.email-settings.email-sender-name',
          'type' => 'text',
          'info' => 'admin::app.configuration.index.email.email-settings.email-sender-name-tip',
          'validation' => 'required|max:50',
          'channel_based' => true,
          'default_value' => '',
        ),
        1 => 
        array (
          'name' => 'shop_email_from',
          'title' => 'admin::app.configuration.index.email.email-settings.shop-email-from',
          'type' => 'text',
          'info' => 'admin::app.configuration.index.email.email-settings.shop-email-from-tip',
          'validation' => 'required|email',
          'channel_based' => true,
          'default_value' => 'shop@example.com',
        ),
        2 => 
        array (
          'name' => 'admin_name',
          'title' => 'admin::app.configuration.index.email.email-settings.admin-name',
          'type' => 'text',
          'info' => 'admin::app.configuration.index.email.email-settings.admin-name-tip',
          'validation' => 'required|max:50',
          'channel_based' => true,
          'default_value' => '',
        ),
        3 => 
        array (
          'name' => 'admin_email',
          'title' => 'admin::app.configuration.index.email.email-settings.admin-email',
          'type' => 'text',
          'info' => 'admin::app.configuration.index.email.email-settings.admin-email-tip',
          'validation' => 'required|email',
          'channel_based' => true,
          'default_value' => '',
        ),
      ),
    ),
    38 => 
    array (
      'key' => 'emails.general',
      'name' => 'admin::app.configuration.index.email.notifications.title',
      'info' => 'admin::app.configuration.index.email.notifications.info',
      'icon' => 'settings/store.svg',
      'sort' => 1,
    ),
    39 => 
    array (
      'key' => 'emails.general.notifications',
      'name' => 'admin::app.configuration.index.email.notifications.title',
      'info' => 'admin::app.configuration.index.email.notifications.info',
      'sort' => 1,
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'emails.general.notifications.verification',
          'title' => 'admin::app.configuration.index.email.notifications.verification',
          'type' => 'boolean',
        ),
        1 => 
        array (
          'name' => 'emails.general.notifications.registration',
          'title' => 'admin::app.configuration.index.email.notifications.registration',
          'type' => 'boolean',
        ),
        2 => 
        array (
          'name' => 'emails.general.notifications.customer_registration_confirmation_mail_to_admin',
          'title' => 'admin::app.configuration.index.email.notifications.customer-registration-confirmation-mail-to-admin',
          'type' => 'boolean',
        ),
        3 => 
        array (
          'name' => 'emails.general.notifications.customer',
          'title' => 'admin::app.configuration.index.email.notifications.customer',
          'type' => 'boolean',
        ),
        4 => 
        array (
          'name' => 'emails.general.notifications.new_order',
          'title' => 'admin::app.configuration.index.email.notifications.new-order',
          'type' => 'boolean',
        ),
        5 => 
        array (
          'name' => 'emails.general.notifications.new_admin',
          'title' => 'admin::app.configuration.index.email.notifications.new-admin',
          'type' => 'boolean',
        ),
        6 => 
        array (
          'name' => 'emails.general.notifications.new_invoice',
          'title' => 'admin::app.configuration.index.email.notifications.new-invoice',
          'type' => 'boolean',
        ),
        7 => 
        array (
          'name' => 'emails.general.notifications.new_refund',
          'title' => 'admin::app.configuration.index.email.notifications.new-refund',
          'type' => 'boolean',
        ),
        8 => 
        array (
          'name' => 'emails.general.notifications.new_shipment',
          'title' => 'admin::app.configuration.index.email.notifications.new-shipment',
          'type' => 'boolean',
        ),
        9 => 
        array (
          'name' => 'emails.general.notifications.new_inventory_source',
          'title' => 'admin::app.configuration.index.email.notifications.new-inventory-source',
          'type' => 'boolean',
        ),
        10 => 
        array (
          'name' => 'emails.general.notifications.cancel_order',
          'title' => 'admin::app.configuration.index.email.notifications.cancel-order',
          'type' => 'boolean',
        ),
      ),
    ),
    40 => 
    array (
      'key' => 'sales',
      'name' => 'admin::app.configuration.index.sales.title',
      'info' => 'admin::app.configuration.index.sales.info',
      'sort' => 5,
    ),
    41 => 
    array (
      'key' => 'sales.shipping',
      'name' => 'admin::app.configuration.index.sales.shipping.title',
      'info' => 'admin::app.configuration.index.sales.shipping.info',
      'icon' => 'settings/shipping.svg',
      'sort' => 1,
    ),
    42 => 
    array (
      'key' => 'sales.shipping.origin',
      'name' => 'admin::app.configuration.index.sales.shipping.origin.title',
      'info' => 'admin::app.configuration.index.sales.shipping.origin.title-info',
      'sort' => 0,
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'country',
          'title' => 'admin::app.configuration.index.sales.shipping.origin.country',
          'type' => 'country',
          'validation' => 'required',
          'channel_based' => true,
          'locale_based' => true,
        ),
        1 => 
        array (
          'name' => 'state',
          'title' => 'admin::app.configuration.index.sales.shipping.origin.state',
          'type' => 'state',
          'validation' => 'required',
          'channel_based' => true,
          'locale_based' => true,
        ),
        2 => 
        array (
          'name' => 'city',
          'title' => 'admin::app.configuration.index.sales.shipping.origin.city',
          'type' => 'text',
          'validation' => 'required',
          'channel_based' => true,
          'locale_based' => false,
        ),
        3 => 
        array (
          'name' => 'address1',
          'title' => 'admin::app.configuration.index.sales.shipping.origin.street-address',
          'type' => 'text',
          'validation' => 'required',
          'channel_based' => true,
          'locale_based' => false,
        ),
        4 => 
        array (
          'name' => 'zipcode',
          'title' => 'admin::app.configuration.index.sales.shipping.origin.zip',
          'type' => 'text',
          'validation' => 'required',
          'channel_based' => true,
          'locale_based' => false,
        ),
        5 => 
        array (
          'name' => 'store_name',
          'title' => 'admin::app.configuration.index.sales.shipping.origin.store-name',
          'type' => 'text',
          'channel_based' => true,
        ),
        6 => 
        array (
          'name' => 'vat_number',
          'title' => 'admin::app.configuration.index.sales.shipping.origin.vat-number',
          'type' => 'text',
          'channel_based' => true,
        ),
        7 => 
        array (
          'name' => 'contact',
          'title' => 'admin::app.configuration.index.sales.shipping.origin.contact-number',
          'type' => 'text',
          'channel_based' => true,
        ),
        8 => 
        array (
          'name' => 'bank_details',
          'title' => 'admin::app.configuration.index.sales.shipping.origin.bank-details',
          'type' => 'textarea',
          'channel_based' => true,
        ),
      ),
    ),
    43 => 
    array (
      'key' => 'sales.carriers',
      'name' => 'admin::app.configuration.index.sales.shipping-methods.title',
      'info' => 'admin::app.configuration.index.sales.shipping-methods.info',
      'icon' => 'settings/shipping-method.svg',
      'sort' => 2,
    ),
    44 => 
    array (
      'key' => 'sales.carriers.free',
      'name' => 'admin::app.configuration.index.sales.shipping-methods.free-shipping.page-title',
      'info' => 'admin::app.configuration.index.sales.shipping-methods.free-shipping.title-info',
      'sort' => 1,
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'title',
          'title' => 'admin::app.configuration.index.sales.shipping-methods.free-shipping.title',
          'type' => 'depends',
          'depend' => 'active:1',
          'validation' => 'required_if:active,1',
          'channel_based' => true,
          'locale_based' => true,
        ),
        1 => 
        array (
          'name' => 'description',
          'title' => 'admin::app.configuration.index.sales.shipping-methods.free-shipping.description',
          'type' => 'textarea',
          'channel_based' => true,
          'locale_based' => true,
        ),
        2 => 
        array (
          'name' => 'active',
          'title' => 'admin::app.configuration.index.sales.shipping-methods.free-shipping.status',
          'type' => 'boolean',
          'channel_based' => true,
          'locale_based' => false,
        ),
      ),
    ),
    45 => 
    array (
      'key' => 'sales.carriers.flatrate',
      'name' => 'admin::app.configuration.index.sales.shipping-methods.flat-rate-shipping.page-title',
      'info' => 'admin::app.configuration.index.sales.shipping-methods.flat-rate-shipping.title-info',
      'sort' => 2,
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'title',
          'title' => 'admin::app.configuration.index.sales.shipping-methods.flat-rate-shipping.title',
          'type' => 'depends',
          'depend' => 'active:1',
          'validation' => 'required_if:active,1',
          'channel_based' => true,
          'locale_based' => true,
        ),
        1 => 
        array (
          'name' => 'description',
          'title' => 'admin::app.configuration.index.sales.shipping-methods.flat-rate-shipping.description',
          'type' => 'textarea',
          'channel_based' => true,
          'locale_based' => true,
        ),
        2 => 
        array (
          'name' => 'default_rate',
          'title' => 'admin::app.configuration.index.sales.shipping-methods.flat-rate-shipping.rate',
          'type' => 'depends',
          'depend' => 'active:1',
          'validation' => 'required_if:active,1',
          'channel_based' => true,
          'locale_based' => false,
        ),
        3 => 
        array (
          'name' => 'type',
          'title' => 'admin::app.configuration.index.sales.shipping-methods.flat-rate-shipping.type',
          'type' => 'select',
          'options' => 
          array (
            0 => 
            array (
              'title' => 'Per Unit',
              'value' => 'per_unit',
            ),
            1 => 
            array (
              'title' => 'Per Order',
              'value' => 'per_order',
            ),
          ),
          'channel_based' => true,
          'locale_based' => false,
        ),
        4 => 
        array (
          'name' => 'active',
          'title' => 'admin::app.configuration.index.sales.shipping-methods.flat-rate-shipping.status',
          'type' => 'boolean',
          'channel_based' => true,
          'locale_based' => false,
        ),
      ),
    ),
    46 => 
    array (
      'key' => 'sales.payment_methods',
      'name' => 'admin::app.configuration.index.sales.payment-methods.page-title',
      'info' => 'admin::app.configuration.index.sales.payment-methods.info',
      'icon' => 'settings/payment-method.svg',
      'sort' => 3,
    ),
    47 => 
    array (
      'key' => 'sales.payment_methods.cashondelivery',
      'name' => 'admin::app.configuration.index.sales.payment-methods.cash-on-delivery',
      'info' => 'admin::app.configuration.index.sales.payment-methods.cash-on-delivery-info',
      'sort' => 1,
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'title',
          'title' => 'admin::app.configuration.index.sales.payment-methods.title',
          'type' => 'depends',
          'depend' => 'active:1',
          'validation' => 'required_if:active,1',
          'channel_based' => true,
          'locale_based' => true,
        ),
        1 => 
        array (
          'name' => 'description',
          'title' => 'admin::app.configuration.index.sales.payment-methods.description',
          'type' => 'textarea',
          'channel_based' => true,
          'locale_based' => true,
        ),
        2 => 
        array (
          'name' => 'instructions',
          'title' => 'admin::app.configuration.index.sales.payment-methods.instructions',
          'type' => 'textarea',
          'channel_based' => true,
          'locale_based' => true,
        ),
        3 => 
        array (
          'name' => 'generate_invoice',
          'title' => 'admin::app.configuration.index.sales.payment-methods.generate-invoice',
          'type' => 'boolean',
          'default_value' => false,
          'channel_based' => true,
          'locale_based' => false,
        ),
        4 => 
        array (
          'name' => 'invoice_status',
          'title' => 'admin::app.configuration.index.sales.payment-methods.set-invoice-status',
          'validation' => 'required_if:generate_invoice,1',
          'type' => 'select',
          'options' => 
          array (
            0 => 
            array (
              'title' => 'admin::app.configuration.index.sales.payment-methods.pending',
              'value' => 'pending',
            ),
            1 => 
            array (
              'title' => 'admin::app.configuration.index.sales.payment-methods.paid',
              'value' => 'paid',
            ),
          ),
          'info' => 'admin::app.configuration.index.sales.payment-methods.set-order-status',
          'channel_based' => true,
          'locale_based' => false,
        ),
        5 => 
        array (
          'name' => 'order_status',
          'title' => 'admin::app.configuration.index.sales.payment-methods.set-order-status',
          'type' => 'select',
          'options' => 
          array (
            0 => 
            array (
              'title' => 'admin::app.configuration.index.sales.payment-methods.pending',
              'value' => 'pending',
            ),
            1 => 
            array (
              'title' => 'admin::app.configuration.index.sales.payment-methods.pending-payment',
              'value' => 'pending_payment',
            ),
            2 => 
            array (
              'title' => 'admin::app.configuration.index.sales.payment-methods.processing',
              'value' => 'processing',
            ),
          ),
          'info' => 'admin::app.configuration.index.sales.payment-methods.generate-invoice-applicable',
          'channel_based' => true,
          'locale_based' => false,
        ),
        6 => 
        array (
          'name' => 'active',
          'title' => 'admin::app.configuration.index.sales.payment-methods.status',
          'type' => 'boolean',
          'channel_based' => true,
          'locale_based' => false,
        ),
        7 => 
        array (
          'name' => 'sort',
          'title' => 'admin::app.configuration.index.sales.payment-methods.sort-order',
          'type' => 'select',
          'options' => 
          array (
            0 => 
            array (
              'title' => '1',
              'value' => 1,
            ),
            1 => 
            array (
              'title' => '2',
              'value' => 2,
            ),
            2 => 
            array (
              'title' => '3',
              'value' => 3,
            ),
            3 => 
            array (
              'title' => '4',
              'value' => 4,
            ),
          ),
        ),
      ),
    ),
    48 => 
    array (
      'key' => 'sales.payment_methods.moneytransfer',
      'name' => 'admin::app.configuration.index.sales.payment-methods.money-transfer',
      'info' => 'admin::app.configuration.index.sales.payment-methods.money-transfer-info',
      'sort' => 2,
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'title',
          'title' => 'admin::app.configuration.index.sales.payment-methods.title',
          'type' => 'depends',
          'depend' => 'active:1',
          'validation' => 'required_if:active,1',
          'channel_based' => true,
          'locale_based' => true,
        ),
        1 => 
        array (
          'name' => 'description',
          'title' => 'admin::app.configuration.index.sales.payment-methods.description',
          'type' => 'textarea',
          'channel_based' => true,
          'locale_based' => true,
        ),
        2 => 
        array (
          'name' => 'generate_invoice',
          'title' => 'admin::app.configuration.index.sales.payment-methods.generate-invoice',
          'type' => 'boolean',
          'default_value' => false,
          'channel_based' => true,
          'locale_based' => false,
        ),
        3 => 
        array (
          'name' => 'invoice_status',
          'title' => 'admin::app.configuration.index.sales.payment-methods.set-invoice-status',
          'type' => 'select',
          'options' => 
          array (
            0 => 
            array (
              'title' => 'admin::app.configuration.index.sales.payment-methods.pending',
              'value' => 'pending',
            ),
            1 => 
            array (
              'title' => 'admin::app.configuration.index.sales.payment-methods.paid',
              'value' => 'paid',
            ),
          ),
          'info' => 'admin::app.configuration.index.sales.payment-methods.generate-invoice-applicable',
          'channel_based' => true,
          'locale_based' => false,
        ),
        4 => 
        array (
          'name' => 'order_status',
          'title' => 'admin::app.configuration.index.sales.payment-methods.set-order-status',
          'type' => 'select',
          'options' => 
          array (
            0 => 
            array (
              'title' => 'admin::app.configuration.index.sales.payment-methods.pending',
              'value' => 'pending',
            ),
            1 => 
            array (
              'title' => 'admin::app.configuration.index.sales.payment-methods.pending-payment',
              'value' => 'pending_payment',
            ),
            2 => 
            array (
              'title' => 'admin::app.configuration.index.sales.payment-methods.processing',
              'value' => 'processing',
            ),
          ),
          'info' => 'admin::app.configuration.index.sales.payment-methods.generate-invoice-applicable',
          'channel_based' => true,
          'locale_based' => false,
        ),
        5 => 
        array (
          'name' => 'mailing_address',
          'title' => 'admin::app.configuration.index.sales.payment-methods.mailing-address',
          'type' => 'textarea',
          'channel_based' => true,
          'locale_based' => true,
        ),
        6 => 
        array (
          'name' => 'active',
          'title' => 'admin::app.configuration.index.sales.payment-methods.status',
          'type' => 'boolean',
          'channel_based' => true,
          'locale_based' => false,
        ),
        7 => 
        array (
          'name' => 'sort',
          'title' => 'admin::app.configuration.index.sales.payment-methods.sort-order',
          'type' => 'select',
          'options' => 
          array (
            0 => 
            array (
              'title' => '1',
              'value' => 1,
            ),
            1 => 
            array (
              'title' => '2',
              'value' => 2,
            ),
            2 => 
            array (
              'title' => '3',
              'value' => 3,
            ),
            3 => 
            array (
              'title' => '4',
              'value' => 4,
            ),
          ),
        ),
      ),
    ),
    49 => 
    array (
      'key' => 'sales.payment_methods.paypal_standard',
      'name' => 'admin::app.configuration.index.sales.payment-methods.paypal-standard',
      'info' => 'admin::app.configuration.index.sales.payment-methods.paypal-standard-info',
      'sort' => 3,
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'title',
          'title' => 'admin::app.configuration.index.sales.payment-methods.title',
          'type' => 'depends',
          'depend' => 'active:1',
          'validation' => 'required_if:active,1',
          'channel_based' => true,
          'locale_based' => true,
        ),
        1 => 
        array (
          'name' => 'description',
          'title' => 'admin::app.configuration.index.sales.payment-methods.description',
          'type' => 'textarea',
          'channel_based' => true,
          'locale_based' => true,
        ),
        2 => 
        array (
          'name' => 'business_account',
          'title' => 'admin::app.configuration.index.sales.payment-methods.business-account',
          'type' => 'depends',
          'depend' => 'active:1',
          'validation' => 'required_if:active,1',
          'channel_based' => true,
          'locale_based' => false,
        ),
        3 => 
        array (
          'name' => 'active',
          'title' => 'admin::app.configuration.index.sales.payment-methods.status',
          'type' => 'boolean',
          'channel_based' => true,
          'locale_based' => false,
        ),
        4 => 
        array (
          'name' => 'sandbox',
          'title' => 'admin::app.configuration.index.sales.payment-methods.sandbox',
          'type' => 'boolean',
          'channel_based' => true,
          'locale_based' => false,
        ),
        5 => 
        array (
          'name' => 'sort',
          'title' => 'admin::app.configuration.index.sales.payment-methods.sort-order',
          'type' => 'select',
          'options' => 
          array (
            0 => 
            array (
              'title' => '1',
              'value' => 1,
            ),
            1 => 
            array (
              'title' => '2',
              'value' => 2,
            ),
            2 => 
            array (
              'title' => '3',
              'value' => 3,
            ),
            3 => 
            array (
              'title' => '4',
              'value' => 4,
            ),
          ),
        ),
      ),
    ),
    50 => 
    array (
      'key' => 'sales.payment_methods.paypal_smart_button',
      'name' => 'admin::app.configuration.index.sales.payment-methods.paypal-smart-button',
      'info' => 'admin::app.configuration.index.sales.payment-methods.paypal-smart-button-info',
      'sort' => 0,
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'title',
          'title' => 'admin::app.configuration.index.sales.payment-methods.title',
          'type' => 'depends',
          'depend' => 'active:1',
          'validation' => 'required_if:active,1',
          'channel_based' => true,
          'locale_based' => true,
        ),
        1 => 
        array (
          'name' => 'description',
          'title' => 'admin::app.configuration.index.sales.payment-methods.description',
          'type' => 'textarea',
          'channel_based' => true,
          'locale_based' => true,
        ),
        2 => 
        array (
          'name' => 'client_id',
          'title' => 'admin::app.configuration.index.sales.payment-methods.client-id',
          'info' => 'admin::app.configuration.index.sales.payment-methods.client-id-info',
          'type' => 'depends',
          'depend' => 'active:1',
          'validation' => 'required_if:active,true',
          'channel_based' => true,
          'locale_based' => false,
        ),
        3 => 
        array (
          'name' => 'client_secret',
          'title' => 'admin::app.configuration.index.sales.payment-methods.client-secret',
          'info' => 'admin::app.configuration.index.sales.payment-methods.client-secret-info',
          'type' => 'depends',
          'depend' => 'active:1',
          'validation' => 'required_if:active,1',
          'channel_based' => true,
          'locale_based' => false,
        ),
        4 => 
        array (
          'name' => 'accepted_currencies',
          'title' => 'admin::app.configuration.index.sales.payment-methods.accepted-currencies',
          'info' => 'admin::app.configuration.index.sales.payment-methods.accepted-currencies-info',
          'type' => 'depends',
          'depend' => 'active:1',
          'validation' => 'required_if:active,1',
          'channel_based' => true,
          'locale_based' => false,
        ),
        5 => 
        array (
          'name' => 'active',
          'title' => 'admin::app.configuration.index.sales.payment-methods.status',
          'type' => 'boolean',
          'channel_based' => true,
          'locale_based' => false,
        ),
        6 => 
        array (
          'name' => 'sandbox',
          'title' => 'admin::app.configuration.index.sales.payment-methods.sandbox',
          'type' => 'boolean',
          'channel_based' => true,
          'locale_based' => false,
        ),
        7 => 
        array (
          'name' => 'sort',
          'title' => 'admin::app.configuration.index.sales.payment-methods.sort-order',
          'type' => 'select',
          'options' => 
          array (
            0 => 
            array (
              'title' => '1',
              'value' => 1,
            ),
            1 => 
            array (
              'title' => '2',
              'value' => 2,
            ),
            2 => 
            array (
              'title' => '3',
              'value' => 3,
            ),
            3 => 
            array (
              'title' => '4',
              'value' => 4,
            ),
          ),
        ),
      ),
    ),
    51 => 
    array (
      'key' => 'sales.order_settings',
      'name' => 'admin::app.configuration.index.sales.order-settings.title',
      'info' => 'admin::app.configuration.index.sales.order-settings.info',
      'icon' => 'settings/order.svg',
      'sort' => 4,
    ),
    52 => 
    array (
      'key' => 'sales.order_settings.order_number',
      'name' => 'admin::app.configuration.index.sales.order-settings.order-number.title',
      'info' => 'admin::app.configuration.index.sales.order-settings.order-number.title-info',
      'sort' => 0,
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'order_number_prefix',
          'title' => 'admin::app.configuration.index.sales.order-settings.order-number.prefix',
          'type' => 'text',
          'validation' => false,
          'channel_based' => true,
          'locale_based' => true,
        ),
        1 => 
        array (
          'name' => 'order_number_length',
          'title' => 'admin::app.configuration.index.sales.order-settings.order-number.length',
          'type' => 'text',
          'validation' => 'numeric',
          'channel_based' => true,
          'locale_based' => true,
        ),
        2 => 
        array (
          'name' => 'order_number_suffix',
          'title' => 'admin::app.configuration.index.sales.order-settings.order-number.suffix',
          'type' => 'text',
          'validation' => false,
          'channel_based' => true,
          'locale_based' => true,
        ),
        3 => 
        array (
          'name' => 'order_number_generator',
          'title' => 'admin::app.configuration.index.sales.order-settings.order-number.generator',
          'type' => 'text',
          'validation' => false,
          'channel_based' => true,
          'locale_based' => true,
        ),
      ),
    ),
    53 => 
    array (
      'key' => 'sales.order_settings.minimum_order',
      'name' => 'admin::app.configuration.index.sales.order-settings.minimum-order.title',
      'info' => 'admin::app.configuration.index.sales.order-settings.minimum-order.title-info',
      'sort' => 1,
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'minimum_order_amount',
          'title' => 'admin::app.configuration.index.sales.order-settings.minimum-order.minimum-order-amount',
          'type' => 'number',
          'validation' => 'regex:^-?\\d+(\\.\\d+)?$',
          'channel_based' => true,
          'locale_based' => true,
        ),
      ),
    ),
    54 => 
    array (
      'key' => 'sales.invoice_settings',
      'name' => 'admin::app.configuration.index.sales.invoice-settings.title',
      'info' => 'admin::app.configuration.index.sales.invoice-settings.info',
      'icon' => 'settings/invoice.svg',
      'sort' => 5,
    ),
    55 => 
    array (
      'key' => 'sales.invoice_settings.invoice_number',
      'name' => 'admin::app.configuration.index.sales.invoice-settings.invoice-number.title',
      'info' => 'admin::app.configuration.index.sales.invoice-settings.invoice-number.title-info',
      'sort' => 0,
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'invoice_number_prefix',
          'title' => 'admin::app.configuration.index.sales.invoice-settings.invoice-number.prefix',
          'type' => 'text',
          'validation' => false,
          'channel_based' => true,
          'locale_based' => true,
        ),
        1 => 
        array (
          'name' => 'invoice_number_length',
          'title' => 'admin::app.configuration.index.sales.invoice-settings.invoice-number.length',
          'type' => 'text',
          'validation' => 'numeric',
          'channel_based' => true,
          'locale_based' => true,
        ),
        2 => 
        array (
          'name' => 'invoice_number_suffix',
          'title' => 'admin::app.configuration.index.sales.invoice-settings.invoice-number.suffix',
          'type' => 'text',
          'validation' => false,
          'channel_based' => true,
          'locale_based' => true,
        ),
        3 => 
        array (
          'name' => 'invoice_number_generator_class',
          'title' => 'admin::app.configuration.index.sales.invoice-settings.invoice-number.generator',
          'type' => 'text',
          'validation' => false,
          'channel_based' => true,
          'locale_based' => true,
        ),
      ),
    ),
    56 => 
    array (
      'key' => 'sales.invoice_settings.payment_terms',
      'name' => 'admin::app.configuration.index.sales.invoice-settings.payment-terms.title',
      'info' => 'admin::app.configuration.index.sales.invoice-settings.payment-terms.title-info',
      'sort' => 1,
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'due_duration',
          'title' => 'admin::app.configuration.index.sales.invoice-settings.payment-terms.due-duration',
          'type' => 'text',
          'validation' => 'numeric',
          'channel_based' => true,
        ),
      ),
    ),
    57 => 
    array (
      'key' => 'sales.invoice_settings.invoice_slip_design',
      'name' => 'admin::app.configuration.index.sales.invoice-settings.invoice-slip-design.title',
      'info' => 'admin::app.configuration.index.sales.invoice-settings.invoice-slip-design.title-info',
      'sort' => 2,
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'logo',
          'title' => 'admin::app.configuration.index.sales.invoice-settings.invoice-slip-design.logo',
          'type' => 'image',
          'validation' => 'mimes:bmp,jpeg,jpg,png,webp',
          'channel_based' => true,
        ),
      ),
    ),
    58 => 
    array (
      'key' => 'sales.invoice_settings.invoice_reminders',
      'name' => 'admin::app.configuration.index.sales.invoice-settings.invoice-reminders.title',
      'info' => 'admin::app.configuration.index.sales.invoice-settings.invoice-reminders.title-info',
      'sort' => 2,
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'reminders_limit',
          'title' => 'admin::app.configuration.index.sales.invoice-settings.invoice-reminders.maximum-limit-of-reminders',
          'type' => 'text',
          'validation' => 'numeric',
          'channel_based' => true,
        ),
        1 => 
        array (
          'name' => 'interval_between_reminders',
          'title' => 'admin::app.configuration.index.sales.invoice-settings.invoice-reminders.interval-between-reminders',
          'type' => 'select',
          'options' => 
          array (
            0 => 
            array (
              'title' => '1 day',
              'value' => 'P1D',
            ),
            1 => 
            array (
              'title' => '2 days',
              'value' => 'P2D',
            ),
            2 => 
            array (
              'title' => '3 days',
              'value' => 'P3D',
            ),
            3 => 
            array (
              'title' => '4 days',
              'value' => 'P4D',
            ),
            4 => 
            array (
              'title' => '5 days',
              'value' => 'P4D',
            ),
            5 => 
            array (
              'title' => '6 days',
              'value' => 'P4D',
            ),
            6 => 
            array (
              'title' => '7 days',
              'value' => 'P4D',
            ),
            7 => 
            array (
              'title' => '2 weeks',
              'value' => 'P2W',
            ),
            8 => 
            array (
              'title' => '3 weeks',
              'value' => 'P3W',
            ),
            9 => 
            array (
              'title' => '4 weeks',
              'value' => 'P4W',
            ),
          ),
        ),
      ),
    ),
    59 => 
    array (
      'key' => 'taxes',
      'name' => 'admin::app.configuration.index.taxes.title',
      'info' => 'admin::app.configuration.index.taxes.title',
      'sort' => 6,
    ),
    60 => 
    array (
      'key' => 'taxes.catalogue',
      'name' => 'admin::app.configuration.index.taxes.catalog.title',
      'info' => 'admin::app.configuration.index.taxes.catalog.title-info',
      'icon' => 'settings/tax.svg',
      'sort' => 1,
    ),
    61 => 
    array (
      'key' => 'taxes.catalogue.pricing',
      'name' => 'admin::app.configuration.index.taxes.catalog.pricing.title',
      'info' => 'admin::app.configuration.index.taxes.catalog.pricing.title-info',
      'sort' => 1,
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'tax_inclusive',
          'title' => 'admin::app.configuration.index.taxes.catalog.pricing.tax-inclusive',
          'type' => 'boolean',
          'default' => false,
        ),
      ),
    ),
    62 => 
    array (
      'key' => 'taxes.catalogue.default_location_calculation',
      'name' => 'admin::app.configuration.index.taxes.catalog.default-location-calculation.title',
      'info' => 'admin::app.configuration.index.taxes.catalog.default-location-calculation.title-info',
      'sort' => 1,
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'country',
          'title' => 'admin::app.configuration.index.taxes.catalog.default-location-calculation.default-country',
          'type' => 'country',
          'default' => '',
        ),
        1 => 
        array (
          'name' => 'state',
          'title' => 'admin::app.configuration.index.taxes.catalog.default-location-calculation.default-state',
          'type' => 'state',
          'default' => '',
        ),
        2 => 
        array (
          'name' => 'post_code',
          'title' => 'admin::app.configuration.index.taxes.catalog.default-location-calculation.default-post-code',
          'type' => 'text',
          'default' => '',
        ),
      ),
    ),
  ),
  'payment_methods' => 
  array (
    'paypal_smart_button' => 
    array (
      'code' => 'paypal_smart_button',
      'title' => 'PayPal Smart Button',
      'description' => 'PayPal',
      'client_id' => 'sb',
      'class' => 'Webkul\\Paypal\\Payment\\SmartButton',
      'sandbox' => true,
      'active' => true,
      'sort' => 0,
    ),
    'paypal_standard' => 
    array (
      'code' => 'paypal_standard',
      'title' => 'PayPal Standard',
      'description' => 'PayPal Standard',
      'class' => 'Webkul\\Paypal\\Payment\\Standard',
      'sandbox' => true,
      'active' => true,
      'business_account' => 'test@webkul.com',
      'sort' => 3,
    ),
    'cashondelivery' => 
    array (
      'code' => 'cashondelivery',
      'title' => 'Cash On Delivery',
      'description' => 'Cash On Delivery',
      'class' => 'Webkul\\Payment\\Payment\\CashOnDelivery',
      'active' => true,
      'sort' => 1,
    ),
    'moneytransfer' => 
    array (
      'code' => 'moneytransfer',
      'title' => 'Money Transfer',
      'description' => 'Money Transfer',
      'class' => 'Webkul\\Payment\\Payment\\MoneyTransfer',
      'active' => true,
      'sort' => 2,
    ),
  ),
  'product_types' => 
  array (
    'simple' => 
    array (
      'key' => 'simple',
      'name' => 'Simple',
      'class' => 'Webkul\\Product\\Type\\Simple',
      'sort' => 1,
    ),
    'configurable' => 
    array (
      'key' => 'configurable',
      'name' => 'Configurable',
      'class' => 'Webkul\\Product\\Type\\Configurable',
      'sort' => 2,
    ),
    'virtual' => 
    array (
      'key' => 'virtual',
      'name' => 'Virtual',
      'class' => 'Webkul\\Product\\Type\\Virtual',
      'sort' => 3,
    ),
    'grouped' => 
    array (
      'key' => 'grouped',
      'name' => 'Grouped',
      'class' => 'Webkul\\Product\\Type\\Grouped',
      'sort' => 4,
    ),
    'downloadable' => 
    array (
      'key' => 'downloadable',
      'name' => 'Downloadable',
      'class' => 'Webkul\\Product\\Type\\Downloadable',
      'sort' => 5,
    ),
    'bundle' => 
    array (
      'key' => 'bundle',
      'name' => 'Bundle',
      'class' => 'Webkul\\Product\\Type\\Bundle',
      'sort' => 6,
    ),
  ),
  'carriers' => 
  array (
    'flatrate' => 
    array (
      'code' => 'flatrate',
      'title' => 'Flat Rate',
      'description' => 'Flat Rate Shipping',
      'active' => true,
      'default_rate' => '10',
      'type' => 'per_unit',
      'class' => 'Webkul\\Shipping\\Carriers\\FlatRate',
    ),
    'free' => 
    array (
      'code' => 'free',
      'title' => 'Free Shipping',
      'description' => 'Free Shipping',
      'active' => true,
      'default_rate' => '0',
      'class' => 'Webkul\\Shipping\\Carriers\\Free',
    ),
  ),
);
