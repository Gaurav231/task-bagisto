<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Authentication Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are used during authentication for various
    | messages that we need to display to the user. You are free to modify
    | these language lines according to your application's requirements.
    |
    */

    'failed'   => 'මෙම හතරවටා අපගේ වාර්තා එකට එකක් නොගැලපෙනි.',
    'throttle' => ':seconds හැකියාවේ නැවත උත්සහ කරන්න.',

];
