<thead {{ $attributes->merge(['class' => 'text-[14px] text-gray-600 dark:text-gray-300 bg-gray-50 border-b-[1px] border-gray-200 dark:border-gray-800']) }}>
    {{ $slot }}
</thead>
