<div class="flex gap-[15px] justify-left pt-[8px] bg-neutral-100 max-sm:hidden">
    <span class="shimmer block w-[141px] h-[40px] bg-gray-300"></span>

    <span class="shimmer block w-[70px] h-[40px] bg-gray-300"></span>

    <span class="shimmer block w-[101px] h-[40px] bg-gray-300"></span>

    <span class="shimmer block w-[208px] h-[40px] bg-gray-300"></span>
</div>