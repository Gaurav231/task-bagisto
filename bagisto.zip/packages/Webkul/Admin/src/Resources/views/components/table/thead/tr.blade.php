<tr {{ $attributes->merge(['scope' => 'row', 'class' => 'border-b dark:border-gray-800']) }}>
    {{ $slot }}
</tr>
