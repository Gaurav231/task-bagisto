<?php

return [
    'name'    => 'Webkul Bagisto Admin',
    'version' => core()->version(),
];
